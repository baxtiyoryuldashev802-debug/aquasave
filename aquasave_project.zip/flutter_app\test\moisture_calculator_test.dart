import 'package:flutter_test/flutter_test.dart';
import '../lib/core/utils/moisture_calculator.dart';

void main() {
  group('MoistureCalculator Tests', () {
    test('Calculates inverted capacitive sensor percentage accurately', () {
      const dryAdc = 3100; // in dry air
      const wetAdc = 1400; // submerged in water

      // Dry sensor test (ADC >= dryAdc -> 0%)
      expect(
        MoistureCalculator.rawAdcToPercent(
          rawAdc: 3200,
          dryAdc: dryAdc,
          wetAdc: wetAdc,
        ),
        equals(0),
      );

      // Submerged sensor test (ADC <= wetAdc -> 100%)
      expect(
        MoistureCalculator.rawAdcToPercent(
          rawAdc: 1300,
          dryAdc: dryAdc,
          wetAdc: wetAdc,
        ),
        equals(100),
      );

      // Midpoint test (~2250 -> ~50%)
      final midPercent = MoistureCalculator.rawAdcToPercent(
        rawAdc: 2250,
        dryAdc: dryAdc,
        wetAdc: wetAdc,
      );
      expect(midPercent, inInclusiveRange(48, 52));
    });

    test('Determines correct moisture state in Uzbek', () {
      expect(MoistureCalculator.getState(20, 35), equals(MoistureState.dry));
      expect(MoistureCalculator.getState(45, 35), equals(MoistureState.normal));
      expect(MoistureCalculator.getState(85, 35), equals(MoistureState.wet));

      expect(MoistureCalculator.getStateTextUz(MoistureState.dry), equals("Quruq"));
      expect(MoistureCalculator.getStateTextUz(MoistureState.normal), equals("Me'yorida"));
      expect(MoistureCalculator.getStateTextUz(MoistureState.wet), equals("Nam"));
    });
  });
}
