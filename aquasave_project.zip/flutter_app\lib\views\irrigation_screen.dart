import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_theme.dart';
import '../controllers/device_controller.dart';
import '../models/command_model.dart';
import '../widgets/emergency_stop_button.dart';
import '../widgets/demo_banner.dart';

class IrrigationScreen extends StatefulWidget {
  const IrrigationScreen({super.key});

  @override
  State<IrrigationScreen> createState() => _IrrigationScreenState();
}

class _IrrigationScreenState extends State<IrrigationScreen> {
  double _manualDuration = 15;

  @override
  Widget build(BuildContext context) {
    final dev = context.watch<DeviceController>();
    final telemetry = dev.telemetry;
    final isPumpOn = telemetry?.pumpOn == true;
    final currentMoisture = telemetry?.moisturePercent ?? 0;
    final threshold = dev.settings.moistureThresholdPercent;
    final hysteresis = dev.settings.hysteresisPercent;
    final autoEnabled = dev.settings.autoModeEnabled;

    // Reason calculation for why auto irrigation would or would not trigger
    String autoReason;
    if (!autoEnabled) {
      autoReason = "Avtomatik rejim o'chiq. Tizim faqat qo'lda buyruqlarni qabul qiladi.";
    } else if (telemetry == null || !telemetry.sensorValid) {
      autoReason = "Sensor nosozligi yoki ma'lumot yo'qligi sababli xavfsizlik uchun to'xtatilgan.";
    } else if (currentMoisture <= threshold) {
      autoReason = "Namlik ($currentMoisture%) belgilangan chegaradan ($threshold%) past. Sug'orish faol!";
    } else if (currentMoisture < threshold + hysteresis) {
      autoReason = "Gisterezis oralig'ida ($threshold% - ${threshold + hysteresis}%). Nasos tez-tez yoqilishidan saqlanmoqda.";
    } else {
      autoReason = "Namlik ($currentMoisture%) yetarli darajada. Sug'orish talab etilmaydi.";
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Sug'orish boshqaruvi"),
      ),
      body: SafeArea(
        child: Column(
          children: [
            DemoBanner(
              isDemoMode: dev.isDemoMode,
              onToggle: () => dev.toggleDemoMode(!dev.isDemoMode),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
                children: [
                  // Real-time pump indicator banner
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: isPumpOn
                            ? [const Color(0xFF065F46), const Color(0xFF047857)]
                            : [AppColors.surface, AppColors.surfaceElevated],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: isPumpOn ? AppColors.accentNeon : AppColors.surfaceBorder,
                        width: isPumpOn ? 1.5 : 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            color: isPumpOn
                                ? AppColors.accentNeon.withOpacity(0.2)
                                : AppColors.surfaceBorder,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            isPumpOn ? Icons.waves_rounded : Icons.water_drop_outlined,
                            color: isPumpOn ? AppColors.accentNeon : AppColors.textMuted,
                            size: 28,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                isPumpOn ? "NASOS ISHLAMOQDA" : "NASOS TO'XTAGAN",
                                style: TextStyle(
                                  color: isPumpOn ? AppColors.accentNeon : AppColors.textSecondary,
                                  fontSize: 13,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: 0.8,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                isPumpOn
                                    ? "ESP32 relesi faol. Suv purkash davom etmoqda."
                                    : "Nasos o'chiq holatda. Bosim normal.",
                                style: const TextStyle(
                                  color: AppColors.textPrimary,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // AUTOMATIC MODE SECTION
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: AppColors.surfaceBorder, width: 1),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Row(
                              children: [
                                Icon(Icons.psychology_alt_rounded, color: AppColors.secondary, size: 22),
                                SizedBox(width: 10),
                                Text(
                                  "Avtomatik sug'orish",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.textPrimary,
                                  ),
                                ),
                              ],
                            ),
                            Switch(
                              value: autoEnabled,
                              onChanged: (val) {
                                dev.setAutoMode(val);
                              },
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Text(
                          autoReason,
                          style: TextStyle(
                            fontSize: 13,
                            color: autoEnabled ? AppColors.secondary : AppColors.textMuted,
                            height: 1.4,
                          ),
                        ),
                        const Divider(color: AppColors.surfaceBorder, height: 32),

                        // Threshold slider
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              "Sug'orish chegarasi",
                              style: TextStyle(
                                fontSize: 14,
                                color: AppColors.textSecondary,
                              ),
                            ),
                            Text(
                              "$threshold%",
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: AppColors.primary,
                              ),
                            ),
                          ],
                        ),
                        Slider(
                          value: threshold.toDouble(),
                          min: 10,
                          max: 60,
                          divisions: 10,
                          label: "$threshold%",
                          onChanged: autoEnabled
                              ? (val) {
                                  dev.updateSettings(
                                    dev.settings.copyWith(
                                      moistureThresholdPercent: val.round(),
                                    ),
                                  );
                                }
                              : null,
                        ),
                        const SizedBox(height: 12),

                        // Hysteresis config
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              "Gisterezis (o'chirish buferi)",
                              style: TextStyle(
                                fontSize: 14,
                                color: AppColors.textSecondary,
                              ),
                            ),
                            Text(
                              "+$hysteresis% (${threshold + hysteresis}% da to'xtaydi)",
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: AppColors.secondary,
                              ),
                            ),
                          ],
                        ),
                        Slider(
                          value: hysteresis.toDouble(),
                          min: 2,
                          max: 15,
                          divisions: 13,
                          onChanged: autoEnabled
                              ? (val) {
                                  dev.updateSettings(
                                    dev.settings.copyWith(
                                      hysteresisPercent: val.round(),
                                    ),
                                  );
                                }
                              : null,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // MANUAL CONTROL SECTION
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: AppColors.surfaceBorder, width: 1),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Row(
                          children: [
                            Icon(Icons.touch_app_rounded, color: AppColors.primary, size: 22),
                            SizedBox(width: 10),
                            Text(
                              "Qo'lda boshqarish",
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: AppColors.textPrimary,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              "Nasos ishlash muddati:",
                              style: TextStyle(
                                fontSize: 14,
                                color: AppColors.textSecondary,
                              ),
                            ),
                            Text(
                              "${_manualDuration.round()} soniya",
                              style: const TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.w700,
                                color: AppColors.textPrimary,
                              ),
                            ),
                          ],
                        ),
                        Slider(
                          value: _manualDuration,
                          min: 5,
                          max: 60,
                          divisions: 11,
                          label: "${_manualDuration.round()}s",
                          onChanged: (val) {
                            setState(() {
                              _manualDuration = val;
                            });
                          },
                        ),
                        const SizedBox(height: 16),
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: isPumpOn
                                      ? AppColors.surfaceBorder
                                      : AppColors.primary,
                                  foregroundColor: isPumpOn
                                      ? AppColors.textMuted
                                      : Colors.black,
                                  padding: const EdgeInsets.symmetric(vertical: 14),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                ),
                                onPressed: isPumpOn
                                    ? null
                                    : () {
                                        dev.startPump(durationSec: _manualDuration.round());
                                      },
                                icon: const Icon(Icons.play_arrow_rounded),
                                label: const Text(
                                  "Ishga tushirish",
                                  style: TextStyle(fontWeight: FontWeight.w700),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: ElevatedButton.icon(
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: isPumpOn
                                      ? const Color(0xFFDC2626)
                                      : AppColors.surfaceElevated,
                                  foregroundColor: Colors.white,
                                  padding: const EdgeInsets.symmetric(vertical: 14),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                ),
                                onPressed: isPumpOn
                                    ? () {
                                        dev.stopPump();
                                      }
                                    : null,
                                icon: const Icon(Icons.stop_rounded),
                                label: const Text(
                                  "To'xtatish",
                                  style: TextStyle(fontWeight: FontWeight.w700),
                                ),
                              ),
                            ),
                          ],
                        ),
                        if (dev.lastCommandMessage != null) ...[
                          const SizedBox(height: 14),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: AppColors.surfaceElevated,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  dev.lastCommandStatus == CommandStatus.completed ||
                                          dev.lastCommandStatus == CommandStatus.accepted
                                      ? Icons.check_circle_outline_rounded
                                      : Icons.info_outline_rounded,
                                  size: 16,
                                  color: AppColors.primary,
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    dev.lastCommandMessage!,
                                    style: const TextStyle(
                                      fontSize: 12,
                                      color: AppColors.textSecondary,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Emergency Stop Button
                  EmergencyStopButton(
                    onStop: () => dev.emergencyStop(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
