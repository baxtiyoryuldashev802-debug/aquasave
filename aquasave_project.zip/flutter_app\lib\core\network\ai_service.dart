import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_constants.dart';
import '../../models/telemetry_model.dart';

class AiInterpretationResult {
  final String action;
  final Map<String, dynamic> params;
  final String naturalResponseUz;
  final bool requiresConfirmation;
  final String? confirmationPromptUz;
  final bool isClarification;

  AiInterpretationResult({
    required this.action,
    this.params = const {},
    required this.naturalResponseUz,
    this.requiresConfirmation = false,
    this.confirmationPromptUz,
    this.isClarification = false,
  });
}

class AiService {
  final String proxyUrl;
  final http.Client _client;

  AiService({
    required this.proxyUrl,
    http.Client? client,
  }) : _client = client ?? http.Client();

  /// Interprets natural language voice/text via the secure OpenAI proxy
  Future<AiInterpretationResult> interpretCommand({
    required String prompt,
    required TelemetryModel currentTelemetry,
    required bool isDemoMode,
  }) async {
    // If proxy URL is reachable, use OpenAI Function Calling via server proxy
    try {
      final payload = {
        'prompt': prompt,
        'current_telemetry': currentTelemetry.toJson(),
        'is_demo_mode': isDemoMode,
      };

      final response = await _client
          .post(
            Uri.parse(proxyUrl),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(payload),
          )
          .timeout(const Duration(seconds: 8));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final rawAction = data['action']?.toString().toUpperCase() ?? 'NONE';

        // Validate strictly against allowlist
        if (!AppConstants.allowlistedActions.contains(rawAction)) {
          return AiInterpretationResult(
            action: 'NONE',
            naturalResponseUz: data['natural_response'] ??
                "Kechirasiz, ushbu buyruq AquaSave xavfsizlik ro'yxatida mavjud emas.",
            isClarification: true,
          );
        }

        return AiInterpretationResult(
          action: rawAction,
          params: (data['params'] as Map<String, dynamic>?) ?? {},
          naturalResponseUz: data['natural_response'] ?? "Buyruq qabul qilindi.",
          requiresConfirmation: data['requires_confirmation'] == true,
          confirmationPromptUz: data['confirmation_prompt'],
        );
      }
    } catch (_) {
      // Fallback to embedded Uzbek deterministic natural language parser
    }

    return _fallbackUzbekParser(prompt, currentTelemetry);
  }

  /// High-reliability embedded Uzbek NLP parser (acts as local offline AI)
  AiInterpretationResult _fallbackUzbekParser(
    String prompt,
    TelemetryModel telemetry,
  ) {
    final lower = prompt.toLowerCase().trim();

    // 1. Soil moisture questions
    if (lower.contains('namlik') ||
        lower.contains('tuproq') ||
        lower.contains('namligi qancha') ||
        lower.contains('holati')) {
      if (!telemetry.sensorValid) {
        return AiInterpretationResult(
          action: 'GET_MOISTURE',
          naturalResponseUz:
              "Diqqat: Tuproq namlik datchigidan signal kelmayapti yoki ulanish mavjud emas.",
        );
      }
      return AiInterpretationResult(
        action: 'GET_MOISTURE',
        naturalResponseUz:
            "Hozirgi tuproq namligi: ${telemetry.moisturePercent}%. " +
                (telemetry.moisturePercent < 35
                    ? "Tuproq ancha quruq, sug'orish tavsiya etiladi."
                    : telemetry.moisturePercent > 75
                        ? "Tuproq yetarlicha nam."
                        : "Tuproq holati me'yorida."),
      );
    }

    // 2. Start irrigation
    if (lower.contains("sug'orishni boshla") ||
        lower.contains("suv quy") ||
        lower.contains("suv ber") ||
        lower.contains("nasosni yoq")) {
      return AiInterpretationResult(
        action: 'START_WATER',
        params: {'duration_sec': 15},
        naturalResponseUz: "Sug'orish nasosini 15 soniyaga yoqishga tayyorman.",
        requiresConfirmation: true,
        confirmationPromptUz:
            "Haqiqatan ham nasosni 15 soniyaga ishga tushirmoqchimisiz?",
      );
    }

    // 3. Stop irrigation / Stop pump
    if (lower.contains("nasosni to'xtat") ||
        lower.contains("suvni to'xtat") ||
        lower.contains("o'chir") && lower.contains("nasos")) {
      return AiInterpretationResult(
        action: 'STOP_WATER',
        naturalResponseUz: "Sug'orish nasosi to'xtatildi.",
      );
    }

    // 4. Automatic mode
    if (lower.contains("avtomatik rejim") && (lower.contains("yoq") || lower.contains("o't"))) {
      return AiInterpretationResult(
        action: 'SET_AUTO_MODE',
        naturalResponseUz: "Avtomatik sug'orish rejimi yoqildi.",
      );
    }

    // 5. Manual mode
    if (lower.contains("qo'lda") || lower.contains("manual")) {
      return AiInterpretationResult(
        action: 'SET_MANUAL_MODE',
        naturalResponseUz: "Qo'lda boshqarish rejimiga o'tildi.",
      );
    }

    // 6. Robot movements
    if (lower.contains("oldinga") || lower.contains("oldiga yurgiz")) {
      return AiInterpretationResult(
        action: 'MOVE_FORWARD',
        params: {'duration_ms': 1000},
        naturalResponseUz: "Robot 1 soniya davomida oldinga harakatlanmoqda.",
      );
    }

    if (lower.contains("orqaga")) {
      return AiInterpretationResult(
        action: 'MOVE_REVERSE',
        params: {'duration_ms': 1000},
        naturalResponseUz: "Robot 1 soniya davomida orqaga harakatlanmoqda.",
      );
    }

    if (lower.contains("chapga")) {
      return AiInterpretationResult(
        action: 'TURN_LEFT',
        params: {'duration_ms': 500},
        naturalResponseUz: "Robot chapga burilmoqda.",
      );
    }

    if (lower.contains("o'ngga")) {
      return AiInterpretationResult(
        action: 'TURN_RIGHT',
        params: {'duration_ms': 500},
        naturalResponseUz: "Robot o'ngga burilmoqda.",
      );
    }

    // 7. Stop movement or emergency stop
    if (lower.contains("to'xta") || lower.contains("stop") || lower.contains("to'xtat")) {
      return AiInterpretationResult(
        action: 'STOP_ALL',
        naturalResponseUz: "Barcha harakat va sug'orish zudlik bilan to'xtatildi.",
      );
    }

    // 8. General status
    if (lower.contains("holat") || lower.contains("status")) {
      return AiInterpretationResult(
        action: 'GET_STATUS',
        naturalResponseUz:
            "AquaSave holati: Namlik ${telemetry.moisturePercent}%, Nasos: ${telemetry.pumpOn ? "Yoqilgan" : "O'chiq"}, Rejim: ${telemetry.mode}, Robot: ${telemetry.robotState}.",
      );
    }

    // Clarification needed
    return AiInterpretationResult(
      action: 'NONE',
      naturalResponseUz:
          "Kechirasiz, buyrug'ingizni tushunolmadim. Masalan, 'Tuproq namligi qancha?' yoki 'Sug'orishni boshla' deb aytishingiz mumkin.",
      isClarification: true,
    );
  }
}
