import 'package:flutter/foundation.dart';
import '../core/network/ai_service.dart';
import '../models/telemetry_model.dart';
import 'device_controller.dart';

enum AiState { idle, listening, processing, speaking, error }

class ChatMessage {
  final String id;
  final String text;
  final bool isUser;
  final DateTime timestamp;
  final String? action;
  final bool requiresConfirmation;
  final String? confirmationPrompt;

  ChatMessage({
    required this.id,
    required this.text,
    required this.isUser,
    required this.timestamp,
    this.action,
    this.requiresConfirmation = false,
    this.confirmationPrompt,
  });
}

class AquaAiController extends ChangeNotifier {
  final DeviceController deviceController;
  late AiService _aiService;

  AiState _state = AiState.idle;
  String _currentTranscription = "";
  String? _errorMessage;
  final List<ChatMessage> _messages = [];
  bool _speechFeedbackEnabled = true;

  AquaAiController({required this.deviceController}) {
    _aiService = AiService(
      proxyUrl: deviceController.settings.openAiProxyUrl,
    );
    _seedWelcomeMessage();
  }

  AiState get state => _state;
  String get currentTranscription => _currentTranscription;
  String? get errorMessage => _errorMessage;
  List<ChatMessage> get messages => _messages;
  bool get speechFeedbackEnabled => _speechFeedbackEnabled;

  void toggleSpeechFeedback() {
    _speechFeedbackEnabled = !_speechFeedbackEnabled;
    notifyListeners();
  }

  void _seedWelcomeMessage() {
    _messages.add(
      ChatMessage(
        id: "welcome_01",
        text:
            "Salom! Men AquaAI — aqlli sug'orish va robot yordamchisiman. Siz menga o'zbek tilida ovozli yoki yozma buyruq berishingiz mumkin. Masalan: \"Tuproq namligi qancha?\" yoki \"Sug'orishni boshla\".",
        isUser: false,
        timestamp: DateTime.now(),
      ),
    );
  }

  void startListening() {
    _state = AiState.listening;
    _currentTranscription = "";
    _errorMessage = null;
    notifyListeners();
  }

  void updateTranscription(String text) {
    _currentTranscription = text;
    notifyListeners();
  }

  Future<void> submitVoiceOrText([String? explicitText]) async {
    final query = explicitText ?? _currentTranscription;
    if (query.trim().isEmpty) {
      _state = AiState.idle;
      notifyListeners();
      return;
    }

    _messages.add(
      ChatMessage(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        text: query,
        isUser: true,
        timestamp: DateTime.now(),
      ),
    );

    _state = AiState.processing;
    _currentTranscription = "";
    notifyListeners();

    try {
      final telemetry = deviceController.telemetry ??
          TelemetryModel(
            deviceId: 'unknown',
            moisturePercent: 0,
            rawAdc: 0,
            pumpOn: false,
            mode: 'MANUAL',
            robotState: 'STOPPED',
            sensorValid: false,
            timestamp: DateTime.now(),
          );

      final result = await _aiService.interpretCommand(
        prompt: query,
        currentTelemetry: telemetry,
        isDemoMode: deviceController.isDemoMode,
      );

      final aiMsg = ChatMessage(
        id: (DateTime.now().millisecondsSinceEpoch + 1).toString(),
        text: result.naturalResponseUz,
        isUser: false,
        timestamp: DateTime.now(),
        action: result.action,
        requiresConfirmation: result.requiresConfirmation,
        confirmationPrompt: result.confirmationPromptUz,
      );
      _messages.add(aiMsg);

      // If action is immediate and doesn't require confirmation, execute it:
      if (!result.requiresConfirmation && result.action != 'NONE') {
        _executeAction(result.action, result.params);
      }

      _state = AiState.idle;
      notifyListeners();
    } catch (e) {
      _state = AiState.error;
      _errorMessage = "Xatolik: $e";
      notifyListeners();
    }
  }

  void confirmAction(String action, [Map<String, dynamic>? params]) {
    _executeAction(action, params ?? {});
    _messages.add(
      ChatMessage(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        text: "Buyruq tasdiqlandi va bajarishga yuborildi.",
        isUser: false,
        timestamp: DateTime.now(),
      ),
    );
    notifyListeners();
  }

  void _executeAction(String action, Map<String, dynamic> params) {
    switch (action) {
      case 'START_WATER':
        final duration = params['duration_sec'] as int? ?? 15;
        deviceController.startPump(durationSec: duration);
        break;
      case 'STOP_WATER':
        deviceController.stopPump();
        break;
      case 'SET_AUTO_MODE':
        deviceController.setAutoMode(true);
        break;
      case 'SET_MANUAL_MODE':
        deviceController.setAutoMode(false);
        break;
      case 'MOVE_FORWARD':
        deviceController.startMoving('FORWARD');
        Future.delayed(const Duration(seconds: 1), () => deviceController.stopMoving());
        break;
      case 'MOVE_REVERSE':
        deviceController.startMoving('REVERSE');
        Future.delayed(const Duration(seconds: 1), () => deviceController.stopMoving());
        break;
      case 'TURN_LEFT':
        deviceController.startMoving('LEFT');
        Future.delayed(const Duration(milliseconds: 600), () => deviceController.stopMoving());
        break;
      case 'TURN_RIGHT':
        deviceController.startMoving('RIGHT');
        Future.delayed(const Duration(milliseconds: 600), () => deviceController.stopMoving());
        break;
      case 'STOP_ALL':
      case 'STOP_MOVEMENT':
        deviceController.emergencyStop();
        break;
    }
  }

  void cancelListening() {
    _state = AiState.idle;
    _currentTranscription = "";
    notifyListeners();
  }
}
