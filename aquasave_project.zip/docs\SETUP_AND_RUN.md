# AQUASAVE — SETUP, CONFIGURATION & RUNNING GUIDE

## 1. Quick Launch (Live Web Simulator & AI Proxy)

You can launch and test the complete AquaSave mobile application immediately on your computer:

1. Open a terminal or double click:
   ```cmd
   cd C:\Users\User\.gemini\antigravity\scratch\aquasave
   start_simulator.bat
   ```
   Or run manually:
   ```cmd
   cd backend_proxy
   npm install
   node server.js
   ```
2. Open your browser at: **`http://localhost:3000`**
3. You can toggle between **Demo Mode** (simulated physics) and **Real Device Mode** (connected to ESP32).
4. Use microphone button for voice control in **Uzbek** (`"Tuproq namligi qancha?"`, `"Sug'orishni boshla"`, etc.).

---

## 2. Flutter Mobile Application (Android & iOS)

The Flutter codebase is located in: `C:\Users\User\.gemini\antigravity\scratch\aquasave\flutter_app`

### 2.1. Prerequisites
- Flutter SDK (version 3.0.0 or higher)
- Android Studio / Xcode

### 2.2. Installation & Running
```bash
cd flutter_app
flutter pub get

# Run unit tests:
flutter test

# Run on connected Android device or emulator:
flutter run

# Build release APK for Android:
flutter build apk --release

# Build for iOS:
flutter build ipa
```

---

## 3. ESP32 Flashing Guide (Arduino IDE)

1. Open **Arduino IDE** (already installed in `C:\Users\User\AppData\Local\Programs\Arduino IDE`).
2. Go to **File -> Open** and select:
   `C:\Users\User\.gemini\antigravity\scratch\aquasave\esp32_firmware\aquasave_esp32_firmware.ino`
3. In **Tools -> Board**, select **ESP32 Dev Module**.
4. Connect your ESP32 board via USB Cable.
5. In **Tools -> Port**, select the COM port of your ESP32.
6. Click **Upload**.
7. Once uploaded, the ESP32 will start an Access Point:
   - **SSID:** `AquaSave-Bot-01`
   - **Password:** `aquasavepassword`
   - **Default IP:** `192.168.4.1`

---

## 4. OpenAI API Key Setup (Secure Backend Proxy)

To protect your API key, it is never hardcoded into the mobile app binary:
1. In `backend_proxy/`:
   ```cmd
   copy .env.example .env
   ```
2. Open `.env` and add your OpenAI API key:
   ```env
   OPENAI_API_KEY=sk-proj-your-real-openai-api-key-here
   OPENAI_MODEL=gpt-4o-mini
   ```
3. Restart `node server.js`.
4. If no API key is provided, the system seamlessly uses the built-in deterministic Uzbek offline agronomist engine.
