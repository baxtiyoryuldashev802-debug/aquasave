require('dotenv').config();
const express = require('express');
const cors = require('cors');

const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Serve the Web Mobile Simulator frontend static files
const webAppPath = path.join(__dirname, '..', 'web_mobile_app');
app.use(express.static(webAppPath));

// Strict list of allowed actions for AquaSave
const ALLOWED_ACTIONS = [
  'GET_STATUS',
  'GET_MOISTURE',
  'START_WATER',
  'STOP_WATER',
  'SET_AUTO_MODE',
  'SET_MANUAL_MODE',
  'MOVE_FORWARD',
  'MOVE_REVERSE',
  'TURN_LEFT',
  'TURN_RIGHT',
  'STOP_MOVEMENT',
  'STOP_ALL'
];

/**
 * OpenAI Chat Completion with Function Calling / Structured Tool Schema
 */
const TOOLS_SCHEMA = [
  {
    type: "function",
    function: {
      name: "execute_aquasave_action",
      description: "Controls the AquaSave robot or irrigation pump based on user instruction.",
      parameters: {
        type: "object",
        properties: {
          action: {
            type: "string",
            enum: ALLOWED_ACTIONS,
            description: "The strictly allowed system action to execute."
          },
          params: {
            type: "object",
            properties: {
              duration_sec: {
                type: "integer",
                description: "Irrigation pump duration in seconds (5 to 60)."
              },
              duration_ms: {
                type: "integer",
                description: "Robot movement duration in milliseconds."
              }
            }
          },
          requires_confirmation: {
            type: "boolean",
            description: "Set to true if this action is potentially risky (e.g., turning on physical water pump or rapid robot driving)."
          },
          confirmation_prompt: {
            type: "string",
            description: "Friendly question in Uzbek asking user to confirm this risky action."
          },
          natural_response: {
            type: "string",
            description: "Natural language response in Uzbek explaining what was done or answering the user's status query based on actual telemetry."
          }
        },
        required: ["action", "natural_response"]
      }
    }
  }
];

app.post('/api/ai/chat', async (req, res) => {
  const { prompt, current_telemetry, is_demo_mode } = req.body;

  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: "So'rov matni (prompt) kiritilmadi" });
  }

  const apiKey = process.env.OPENAI_API_KEY;

  // If no OpenAI API Key configured, fallback to high-accuracy deterministic response
  if (!apiKey || apiKey === 'YOUR_OPENAI_API_KEY_HERE') {
    console.log("[PROXY] OpenAI API kaliti topilmadi. Mahalliy qoidalar asosida javob berilmoqda.");
    return res.json(deterministicUzbekAi(prompt, current_telemetry, is_demo_mode));
  }

  try {
    const systemPrompt = `You are AquaAI, the intelligent smart irrigation and mobile robotics voice assistant inside AquaSave.
Language: Uzbek (Latin script).
CRITICAL RULES:
1. Always ground your answers in the ACTUAL device telemetry provided below. Never invent or hallucinate moisture percentages, robot state, or pump status!
2. Only select an action from the strict allowlist.
3. If an action could cause overflow or safety hazards (like START_WATER), set requires_confirmation to true.
4. Keep spoken responses concise, polite, technical, and trustworthy.

CURRENT DEVICE TELEMETRY:
${JSON.stringify(current_telemetry || {}, null, 2)}
DEMO MODE ACTIVE: ${is_demo_mode ? "YES" : "NO"}
`;

    const openAiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: prompt }
        ],
        tools: TOOLS_SCHEMA,
        tool_choice: "auto",
        temperature: 0.2
      })
    });

    if (!openAiResponse.ok) {
      const errText = await openAiResponse.text();
      console.error("[OPENAI ERROR]", errText);
      return res.json(deterministicUzbekAi(prompt, current_telemetry, is_demo_mode));
    }

    const aiData = await openAiResponse.json();
    const message = aiData.choices[0]?.message;

    if (message?.tool_calls && message.tool_calls.length > 0) {
      const toolCall = message.tool_calls[0];
      const parsedArgs = JSON.parse(toolCall.function.arguments);
      return res.json(parsedArgs);
    }

    // Direct text response
    return res.json({
      action: "NONE",
      natural_response: message?.content || "Sizni tushundim. Boshqa qanday yordam bera olaman?",
      requires_confirmation: false
    });

  } catch (error) {
    console.error("[PROXY SERVER EXCEPTION]", error);
    return res.json(deterministicUzbekAi(prompt, current_telemetry, is_demo_mode));
  }
});

/**
 * Fallback deterministic Uzbek agronomist AI engine
 */
function deterministicUzbekAi(prompt, telemetry = {}, isDemo = false) {
  const p = prompt.toLowerCase();
  const moisture = telemetry.moisture_percent ?? 0;
  const pumpOn = telemetry.pump_on === true;
  const sensorValid = telemetry.sensor_valid !== false;

  if (p.includes('namlik') || p.includes('tuproq') || p.includes('holati')) {
    if (!sensorValid) {
      return {
        action: 'GET_MOISTURE',
        natural_response: "Diqqat: Tuproq namlik datchigi ulanmagan yoki nosoz. Aniq o'lchov mavjud emas.",
        requires_confirmation: false
      };
    }
    return {
      action: 'GET_MOISTURE',
      natural_response: `Hozirgi tuproq namligi: ${moisture}%. ` +
        (moisture < 35 ? "Tuproq quruq, o'simliklarni sug'orish maqsadga muvofiq." :
         moisture > 75 ? "Tuproq yetarlicha nam, sug'orish shart emas." : "Tuproq namligi me'yorida."),
      requires_confirmation: false
    };
  }

  if (p.includes("sug'orishni boshla") || p.includes("suv quy") || p.includes("nasosni yoq")) {
    return {
      action: 'START_WATER',
      params: { duration_sec: 15 },
      requires_confirmation: true,
      confirmation_prompt: "Haqiqatan ham sug'orish nasosini 15 soniyaga yoqmoqchimisiz?",
      natural_response: "Sug'orish nasosini 15 soniyaga yoqishga tayyorman. Amalni tasdiqlang."
    };
  }

  if (p.includes("to'xtat") && (p.includes("nasos") || p.includes("suv"))) {
    return {
      action: 'STOP_WATER',
      natural_response: "Sug'orish nasosi darhol o'chirildi.",
      requires_confirmation: false
    };
  }

  if (p.includes("avtomatik")) {
    return {
      action: 'SET_AUTO_MODE',
      natural_response: "Avtomatik sug'orish rejimi faollashtirildi.",
      requires_confirmation: false
    };
  }

  if (p.includes("oldinga")) {
    return {
      action: 'MOVE_FORWARD',
      params: { duration_ms: 1000 },
      natural_response: "Robot oldinga 1 soniya harakatlanmoqda.",
      requires_confirmation: false
    };
  }

  if (p.includes("orqaga")) {
    return {
      action: 'MOVE_REVERSE',
      params: { duration_ms: 1000 },
      natural_response: "Robot orqaga harakatlanmoqda.",
      requires_confirmation: false
    };
  }

  if (p.includes("chapga")) {
    return {
      action: 'TURN_LEFT',
      params: { duration_ms: 500 },
      natural_response: "Robot chapga burilmoqda.",
      requires_confirmation: false
    };
  }

  if (p.includes("o'ngga")) {
    return {
      action: 'TURN_RIGHT',
      params: { duration_ms: 500 },
      natural_response: "Robot o'ngga burilmoqda.",
      requires_confirmation: false
    };
  }

  if (p.includes("to'xta") || p.includes("stop")) {
    return {
      action: 'STOP_ALL',
      natural_response: "Barcha motorlar va suv ta'minoti favqulodda to'xtatildi.",
      requires_confirmation: false
    };
  }

  return {
    action: 'NONE',
    natural_response: "Kechirasiz, buyrug'ingizni tushunolmadim. Masalan, 'Tuproq namligi qancha?' yoki 'Sug'orishni boshla' deb so'rashingiz mumkin.",
    requires_confirmation: false
  };
}

app.listen(PORT, () => {
  console.log(`[AQUASAVE PROXY] Xavfsiz AI Backend Proxy http://localhost:${PORT} da ishga tushdi.`);
  console.log(`OpenAI API himoyalangan va mijoz ilovasiga kalit oshkor qilinmaydi.`);
});
