enum MoistureState {
  dry, // Quruq
  normal, // Me'yorida
  wet, // Nam
  unknown // Noma'lum / Xato
}

class MoistureCalculator {
  /// Converts raw ADC value into a calibrated percentage (0% to 100%).
  /// Most capacitive sensors output HIGH voltage when dry and LOW voltage when submerged.
  static int rawAdcToPercent({
    required int rawAdc,
    required int dryAdc,
    required int wetAdc,
  }) {
    if (rawAdc <= 0 || rawAdc > 4095) {
      return 0; // Sensor disconnected or out of bounds
    }

    // Inverted sensor logic (High ADC = Dry, Low ADC = Wet)
    if (dryAdc > wetAdc) {
      if (rawAdc >= dryAdc) return 0;
      if (rawAdc <= wetAdc) return 100;
      final range = dryAdc - wetAdc;
      final percent = ((dryAdc - rawAdc) / range) * 100;
      return percent.clamp(0, 100).round();
    } else {
      // Standard direct sensor logic
      if (rawAdc <= dryAdc) return 0;
      if (rawAdc >= wetAdc) return 100;
      final range = wetAdc - dryAdc;
      final percent = ((rawAdc - dryAdc) / range) * 100;
      return percent.clamp(0, 100).round();
    }
  }

  /// Determines the human-friendly state in Uzbek
  static MoistureState getState(int percent, int dryThreshold) {
    if (percent < dryThreshold) {
      return MoistureState.dry;
    } else if (percent > 75) {
      return MoistureState.wet;
    } else {
      return MoistureState.normal;
    }
  }

  static String getStateTextUz(MoistureState state) {
    switch (state) {
      case MoistureState.dry:
        return "Quruq";
      case MoistureState.normal:
        return "Me'yorida";
      case MoistureState.wet:
        return "Nam";
      case MoistureState.unknown:
        return "Noma'lum";
    }
  }
}
