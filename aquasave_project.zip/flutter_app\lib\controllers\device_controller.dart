import 'dart:async';
import 'dart:math';
import 'package:flutter/foundation.dart';
import '../models/telemetry_model.dart';
import '../models/command_model.dart';
import '../models/device_settings_model.dart';
import '../models/history_event_model.dart';
import '../core/constants/app_constants.dart';
import '../core/network/esp32_client.dart';
import 'history_controller.dart';

enum DeviceConnectionState {
  connected,
  connecting,
  disconnected,
  sensorError,
  staleData,
}

class DeviceController extends ChangeNotifier {
  final HistoryController historyController;
  late Esp32Client _esp32Client;

  DeviceSettingsModel _settings = DeviceSettingsModel();
  DeviceConnectionState _connectionState = DeviceConnectionState.disconnected;
  TelemetryModel? _telemetry;
  DateTime? _lastSuccessfulFetch;
  Timer? _telemetryTimer;
  Timer? _heartbeatTimer;
  bool _isDisposed = false;

  // Command feedback states
  String? _lastCommandId;
  CommandStatus _lastCommandStatus = CommandStatus.completed;
  String? _lastCommandMessage;

  // Demo simulation state
  double _simulatedMoisture = 28.0;
  bool _simulatedPump = false;
  String _simulatedRobotState = 'STOPPED';

  DeviceController({required this.historyController}) {
    _esp32Client = Esp32Client(
      host: _settings.esp32Host,
      port: _settings.esp32Port,
    );
    _init();
  }

  DeviceSettingsModel get settings => _settings;
  DeviceConnectionState get connectionState => _connectionState;
  TelemetryModel? get telemetry => _telemetry;
  DateTime? get lastSuccessfulFetch => _lastSuccessfulFetch;
  bool get isDemoMode => _settings.isDemoMode;
  CommandStatus get lastCommandStatus => _lastCommandStatus;
  String? get lastCommandMessage => _lastCommandMessage;

  bool get isDataStale {
    if (_telemetry == null || _lastSuccessfulFetch == null) return true;
    return DateTime.now().difference(_lastSuccessfulFetch!) > AppConstants.staleDataThreshold;
  }

  void _init() {
    _startTelemetryLoop();
  }

  void updateSettings(DeviceSettingsModel newSettings) {
    _settings = newSettings;
    _esp32Client = Esp32Client(
      host: _settings.esp32Host,
      port: _settings.esp32Port,
    );
    notifyListeners();
  }

  void toggleDemoMode(bool value) {
    _settings = _settings.copyWith(isDemoMode: value);
    if (value) {
      _connectionState = DeviceConnectionState.connected;
    } else {
      _connectionState = DeviceConnectionState.connecting;
    }
    notifyListeners();
  }

  void _startTelemetryLoop() {
    _telemetryTimer?.cancel();
    _telemetryTimer = Timer.periodic(AppConstants.telemetryRefreshInterval, (_) async {
      if (_isDisposed) return;
      await _fetchTelemetryCycle();
    });
  }

  Future<void> _fetchTelemetryCycle() async {
    if (_settings.isDemoMode) {
      _simulateDemoTelemetry();
      return;
    }

    try {
      final freshTelemetry = await _esp32Client.fetchTelemetry();
      _telemetry = freshTelemetry;
      _lastSuccessfulFetch = DateTime.now();

      if (!_telemetry!.sensorValid) {
        _connectionState = DeviceConnectionState.sensorError;
      } else if (isDataStale) {
        _connectionState = DeviceConnectionState.staleData;
      } else {
        _connectionState = DeviceConnectionState.connected;
      }
      notifyListeners();
    } catch (e) {
      _connectionState = DeviceConnectionState.disconnected;
      notifyListeners();
    }
  }

  void _simulateDemoTelemetry() {
    // Realistic plant physics simulation:
    // If pump is on, moisture increases; otherwise it slowly dries.
    if (_simulatedPump) {
      _simulatedMoisture = (_simulatedMoisture + 1.8).clamp(0.0, 92.0);
    } else {
      _simulatedMoisture = (_simulatedMoisture - 0.05).clamp(15.0, 95.0);
    }

    _telemetry = TelemetryModel(
      deviceId: 'aquasave-demo-01',
      moisturePercent: _simulatedMoisture.round(),
      rawAdc: 2400 + Random().nextInt(50),
      pumpOn: _simulatedPump,
      mode: _settings.autoModeEnabled ? 'AUTO' : 'MANUAL',
      robotState: _simulatedRobotState,
      sensorValid: true,
      timestamp: DateTime.now(),
      batteryMv: 4150,
      wifiRssi: -55,
    );
    _lastSuccessfulFetch = DateTime.now();
    _connectionState = DeviceConnectionState.connected;
    notifyListeners();
  }

  // --- IRRIGATION PUMP CONTROLS ---

  Future<bool> startPump({int? durationSec}) async {
    final duration = durationSec ?? _settings.maxPumpDurationSec;
    final cmd = CommandModel(
      commandId: "PUMP_START_${DateTime.now().millisecondsSinceEpoch}",
      action: 'START_WATER',
      params: {'duration_sec': duration},
      timestamp: DateTime.now(),
    );

    _lastCommandId = cmd.commandId;
    _lastCommandStatus = CommandStatus.pending;
    notifyListeners();

    if (_settings.isDemoMode) {
      _simulatedPump = true;
      _lastCommandStatus = CommandStatus.completed;
      _lastCommandMessage = "Demo: Nasos $duration soniyaga ishga tushirildi";
      historyController.addEvent(
        type: HistoryEventType.pumpStarted,
        title: "Sug'orish boshlandi (Demo)",
        description: "Nasos $duration soniyaga yoqildi",
        moistureValue: _telemetry?.moisturePercent,
        isDemo: true,
      );
      // Auto shutoff after simulated duration
      Timer(Duration(seconds: duration), () {
        if (_simulatedPump) {
          stopPump();
        }
      });
      notifyListeners();
      return true;
    }

    final result = await _esp32Client.sendCommand(cmd);
    _lastCommandStatus = result.status;
    _lastCommandMessage = result.message;

    if (result.status == CommandStatus.accepted || result.status == CommandStatus.completed) {
      historyController.addEvent(
        type: HistoryEventType.pumpStarted,
        title: "Sug'orish boshlandi",
        description: "Nasos $duration soniyaga yoqildi (ESP32 tasdiqladi)",
        moistureValue: _telemetry?.moisturePercent,
        isDemo: false,
      );
      notifyListeners();
      return true;
    } else {
      notifyListeners();
      return false;
    }
  }

  Future<bool> stopPump() async {
    final cmd = CommandModel(
      commandId: "PUMP_STOP_${DateTime.now().millisecondsSinceEpoch}",
      action: 'STOP_WATER',
      timestamp: DateTime.now(),
    );

    _lastCommandId = cmd.commandId;
    _lastCommandStatus = CommandStatus.pending;
    notifyListeners();

    if (_settings.isDemoMode) {
      _simulatedPump = false;
      _lastCommandStatus = CommandStatus.completed;
      _lastCommandMessage = "Demo: Nasos to'xtatildi";
      historyController.addEvent(
        type: HistoryEventType.pumpStopped,
        title: "Sug'orish to'xtatildi (Demo)",
        description: "Foydalanuvchi nasosni to'xtatdi",
        moistureValue: _telemetry?.moisturePercent,
        isDemo: true,
      );
      notifyListeners();
      return true;
    }

    final result = await _esp32Client.sendCommand(cmd);
    _lastCommandStatus = result.status;
    _lastCommandMessage = result.message;

    if (result.status == CommandStatus.accepted || result.status == CommandStatus.completed) {
      historyController.addEvent(
        type: HistoryEventType.pumpStopped,
        title: "Sug'orish to'xtatildi",
        description: "Nasos to'xtatildi (ESP32 tasdiqladi)",
        moistureValue: _telemetry?.moisturePercent,
        isDemo: false,
      );
      notifyListeners();
      return true;
    } else {
      notifyListeners();
      return false;
    }
  }

  Future<void> setAutoMode(bool enabled) async {
    _settings = _settings.copyWith(autoModeEnabled: enabled);
    final cmd = CommandModel(
      commandId: "MODE_${DateTime.now().millisecondsSinceEpoch}",
      action: enabled ? 'SET_AUTO_MODE' : 'SET_MANUAL_MODE',
      params: {
        'threshold': _settings.moistureThresholdPercent,
        'hysteresis': _settings.hysteresisPercent,
      },
      timestamp: DateTime.now(),
    );

    if (_settings.isDemoMode) {
      historyController.addEvent(
        type: HistoryEventType.modeChanged,
        title: enabled ? "Avtomatik rejim yoqildi" : "Qo'lda boshqaruvga o'tildi",
        description: enabled
            ? "Chegara: ${_settings.moistureThresholdPercent}% (Demo)"
            : "Qo'lda rejim (Demo)",
        isDemo: true,
      );
      notifyListeners();
      return;
    }

    final res = await _esp32Client.sendCommand(cmd);
    if (res.status == CommandStatus.accepted || res.status == CommandStatus.completed) {
      historyController.addEvent(
        type: HistoryEventType.modeChanged,
        title: enabled ? "Avtomatik rejim faollashdi" : "Qo'lda rejimga o'tildi",
        description: enabled
            ? "Chegara: ${_settings.moistureThresholdPercent}%"
            : "Qo'lda boshqaruv",
        isDemo: false,
      );
    }
    notifyListeners();
  }

  // --- ROBOT MOVEMENT CONTROLS ---

  /// Starts directional movement with press-and-hold heartbeat
  void startMoving(String direction) {
    if (_connectionState == DeviceConnectionState.disconnected && !_settings.isDemoMode) {
      _lastCommandStatus = CommandStatus.error;
      _lastCommandMessage = "Qurilma tarmoqdan uzilgan! Harakat rad etildi.";
      notifyListeners();
      return;
    }

    _sendMovementHeartbeat(direction);

    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(const Duration(milliseconds: 200), (_) {
      _sendMovementHeartbeat(direction);
    });
  }

  void _sendMovementHeartbeat(String direction) {
    final actionMap = {
      'FORWARD': 'MOVE_FORWARD',
      'REVERSE': 'MOVE_REVERSE',
      'LEFT': 'TURN_LEFT',
      'RIGHT': 'TURN_RIGHT',
    };

    final action = actionMap[direction] ?? 'STOP_MOVEMENT';

    if (_settings.isDemoMode) {
      _simulatedRobotState = direction;
      notifyListeners();
      return;
    }

    final cmd = CommandModel(
      commandId: "MOVE_${DateTime.now().millisecondsSinceEpoch}",
      action: action,
      params: {'heartbeat_ms': AppConstants.motorHeartbeatTimeoutMs},
      timestamp: DateTime.now(),
    );

    _esp32Client.sendCommand(cmd);
  }

  /// Called immediately on touch release
  void stopMoving() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = null;

    if (_settings.isDemoMode) {
      _simulatedRobotState = 'STOPPED';
      notifyListeners();
      return;
    }

    final cmd = CommandModel(
      commandId: "STOP_MOVE_${DateTime.now().millisecondsSinceEpoch}",
      action: 'STOP_MOVEMENT',
      timestamp: DateTime.now(),
    );
    _esp32Client.sendCommand(cmd);
  }

  /// Emergency Stop for both motors and pump
  Future<void> emergencyStop() async {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = null;

    final cmd = CommandModel(
      commandId: "EMERGENCY_STOP_${DateTime.now().millisecondsSinceEpoch}",
      action: 'STOP_ALL',
      timestamp: DateTime.now(),
    );

    if (_settings.isDemoMode) {
      _simulatedPump = false;
      _simulatedRobotState = 'STOPPED';
      _lastCommandStatus = CommandStatus.completed;
      _lastCommandMessage = "XAVFSIZLIK: Barcha tizimlar favqulodda to'xtatildi (Demo)";
      historyController.addEvent(
        type: HistoryEventType.safetyWarning,
        title: "FAVQULODDA TO'XTATISH (Demo)",
        description: "Barcha motorlar va nasos majburiy to'xtatildi",
        isDemo: true,
      );
      notifyListeners();
      return;
    }

    final res = await _esp32Client.sendCommand(cmd);
    historyController.addEvent(
      type: HistoryEventType.safetyWarning,
      title: "FAVQULODDA TO'XTATISH",
      description: "Barcha tizimlar to'xtatildi (ESP32: ${res.status.name})",
      isDemo: false,
    );
    notifyListeners();
  }

  @override
  void dispose() {
    _isDisposed = true;
    _telemetryTimer?.cancel();
    _heartbeatTimer?.cancel();
    _esp32Client.dispose();
    super.dispose();
  }
}
