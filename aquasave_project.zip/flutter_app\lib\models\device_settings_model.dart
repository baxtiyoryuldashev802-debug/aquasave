class DeviceSettingsModel {
  final String deviceName;
  final String esp32Host;
  final int esp32Port;
  final bool autoModeEnabled;
  final int moistureThresholdPercent;
  final int hysteresisPercent;
  final int maxPumpDurationSec;
  final int sensorDryAdc;
  final int sensorWetAdc;
  final bool isDemoMode;
  final String openAiProxyUrl;
  final String language; // "uz" | "en" | "ru"

  DeviceSettingsModel({
    this.deviceName = "AquaSave Bot 01",
    this.esp32Host = "192.168.4.1",
    this.esp32Port = 80,
    this.autoModeEnabled = false,
    this.moistureThresholdPercent = 35,
    this.hysteresisPercent = 5,
    this.maxPumpDurationSec = 30,
    this.sensorDryAdc = 3100,
    this.sensorWetAdc = 1400,
    this.isDemoMode = true,
    this.openAiProxyUrl = "http://localhost:3000/api/ai/chat",
    this.language = "uz",
  });

  Map<String, dynamic> toJson() {
    return {
      'device_name': deviceName,
      'esp32_host': esp32Host,
      'esp32_port': esp32Port,
      'auto_mode_enabled': autoModeEnabled,
      'moisture_threshold_percent': moistureThresholdPercent,
      'hysteresis_percent': hysteresisPercent,
      'max_pump_duration_sec': maxPumpDurationSec,
      'sensor_dry_adc': sensorDryAdc,
      'sensor_wet_adc': sensorWetAdc,
      'is_demo_mode': isDemoMode,
      'openai_proxy_url': openAiProxyUrl,
      'language': language,
    };
  }

  factory DeviceSettingsModel.fromJson(Map<String, dynamic> json) {
    return DeviceSettingsModel(
      deviceName: json['device_name']?.toString() ?? "AquaSave Bot 01",
      esp32Host: json['esp32_host']?.toString() ?? "192.168.4.1",
      esp32Port: (json['esp32_port'] as num?)?.toInt() ?? 80,
      autoModeEnabled: json['auto_mode_enabled'] == true,
      moistureThresholdPercent: (json['moisture_threshold_percent'] as num?)?.toInt() ?? 35,
      hysteresisPercent: (json['hysteresis_percent'] as num?)?.toInt() ?? 5,
      maxPumpDurationSec: (json['max_pump_duration_sec'] as num?)?.toInt() ?? 30,
      sensorDryAdc: (json['sensor_dry_adc'] as num?)?.toInt() ?? 3100,
      sensorWetAdc: (json['sensor_wet_adc'] as num?)?.toInt() ?? 1400,
      isDemoMode: json['is_demo_mode'] ?? true,
      openAiProxyUrl: json['openai_proxy_url']?.toString() ?? "http://localhost:3000/api/ai/chat",
      language: json['language']?.toString() ?? "uz",
    );
  }

  DeviceSettingsModel copyWith({
    String? deviceName,
    String? esp32Host,
    int? esp32Port,
    bool? autoModeEnabled,
    int? moistureThresholdPercent,
    int? hysteresisPercent,
    int? maxPumpDurationSec,
    int? sensorDryAdc,
    int? sensorWetAdc,
    bool? isDemoMode,
    String? openAiProxyUrl,
    String? language,
  }) {
    return DeviceSettingsModel(
      deviceName: deviceName ?? this.deviceName,
      esp32Host: esp32Host ?? this.esp32Host,
      esp32Port: esp32Port ?? this.esp32Port,
      autoModeEnabled: autoModeEnabled ?? this.autoModeEnabled,
      moistureThresholdPercent: moistureThresholdPercent ?? this.moistureThresholdPercent,
      hysteresisPercent: hysteresisPercent ?? this.hysteresisPercent,
      maxPumpDurationSec: maxPumpDurationSec ?? this.maxPumpDurationSec,
      sensorDryAdc: sensorDryAdc ?? this.sensorDryAdc,
      sensorWetAdc: sensorWetAdc ?? this.sensorWetAdc,
      isDemoMode: isDemoMode ?? this.isDemoMode,
      openAiProxyUrl: openAiProxyUrl ?? this.openAiProxyUrl,
      language: language ?? this.language,
    );
  }
}
