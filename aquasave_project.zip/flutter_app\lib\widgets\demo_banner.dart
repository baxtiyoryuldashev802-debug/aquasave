import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class DemoBanner extends StatelessWidget {
  final bool isDemoMode;
  final VoidCallback? onToggle;

  const DemoBanner({
    super.key,
    required this.isDemoMode,
    this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    if (!isDemoMode) return const SizedBox.shrink();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      decoration: BoxDecoration(
        color: AppColors.statusDry.withOpacity(0.15),
        border: Border(
          bottom: BorderSide(
            color: AppColors.statusDry.withOpacity(0.3),
            width: 1,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.science_outlined,
            size: 16,
            color: AppColors.statusDry,
          ),
          const SizedBox(width: 8),
          const Expanded(
            child: Text(
              "DEMO REJIMI — HAQIQIY QURILMA ULANGAN EMAS",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: AppColors.statusDry,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
              ),
            ),
          ),
          if (onToggle != null) ...[
            const SizedBox(width: 8),
            InkWell(
              onTap: onToggle,
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.surfaceBorder,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text(
                  "O'zgartirish",
                  style: TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
