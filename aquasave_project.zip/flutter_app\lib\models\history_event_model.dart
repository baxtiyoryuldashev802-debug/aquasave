enum HistoryEventType {
  moistureReading,
  pumpStarted,
  pumpStopped,
  modeChanged,
  robotMoved,
  error,
  safetyWarning,
}

class HistoryEventModel {
  final String id;
  final DateTime timestamp;
  final HistoryEventType type;
  final String title;
  final String description;
  final int? moistureValue;
  final bool isDemo;

  HistoryEventModel({
    required this.id,
    required this.timestamp,
    required this.type,
    required this.title,
    required this.description,
    this.moistureValue,
    this.isDemo = false,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'timestamp': timestamp.toIso8601String(),
      'type': type.name,
      'title': title,
      'description': description,
      'moisture_value': moistureValue,
      'is_demo': isDemo,
    };
  }

  factory HistoryEventModel.fromJson(Map<String, dynamic> json) {
    return HistoryEventModel(
      id: json['id'] ?? DateTime.now().millisecondsSinceEpoch.toString(),
      timestamp: json['timestamp'] != null
          ? DateTime.tryParse(json['timestamp']) ?? DateTime.now()
          : DateTime.now(),
      type: HistoryEventType.values.firstWhere(
        (e) => e.name == json['type'],
        orElse: () => HistoryEventType.moistureReading,
      ),
      title: json['title'] ?? '',
      description: json['description'] ?? '',
      moistureValue: json['moisture_value'],
      isDemo: json['is_demo'] == true,
    );
  }
}
