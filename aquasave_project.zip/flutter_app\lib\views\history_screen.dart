import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../core/theme/app_theme.dart';
import '../controllers/history_controller.dart';
import '../controllers/device_controller.dart';
import '../models/history_event_model.dart';
import '../widgets/demo_banner.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final history = context.watch<HistoryController>();
    final dev = context.watch<DeviceController>();
    final events = history.events;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Tizim tarixi va tahlili"),
      ),
      body: SafeArea(
        child: Column(
          children: [
            DemoBanner(
              isDemoMode: dev.isDemoMode,
              onToggle: () => dev.toggleDemoMode(!dev.isDemoMode),
            ),
            // Time range filter tabs
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Row(
                children: [
                  _buildFilterTab("Bugun", HistoryFilter.today, history),
                  const SizedBox(width: 8),
                  _buildFilterTab("7 kun", HistoryFilter.week, history),
                  const SizedBox(width: 8),
                  _buildFilterTab("30 kun", HistoryFilter.month, history),
                ],
              ),
            ),

            Expanded(
              child: events.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.history_toggle_off_rounded, size: 48, color: AppColors.textMuted),
                          const SizedBox(height: 12),
                          const Text(
                            "Tarixiy yozuvlar mavjud emas",
                            style: TextStyle(color: AppColors.textSecondary, fontSize: 15, fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            "Sug'orish va datchik ma'lumotlari bu yerda saqlanadi",
                            style: TextStyle(color: AppColors.textMuted, fontSize: 12),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
                      itemCount: events.length,
                      itemBuilder: (context, index) {
                        final event = events[index];
                        return _buildHistoryEventCard(event);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterTab(String label, HistoryFilter filter, HistoryController history) {
    final isSelected = history.selectedFilter == filter;
    return Expanded(
      child: InkWell(
        onTap: () => history.setFilter(filter),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: isSelected ? AppColors.primary : AppColors.surfaceElevated,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected ? AppColors.primary : AppColors.surfaceBorder,
            ),
          ),
          child: Center(
            child: Text(
              label,
              style: TextStyle(
                color: isSelected ? Colors.black : AppColors.textSecondary,
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHistoryEventCard(HistoryEventModel event) {
    IconData icon;
    Color iconColor;

    switch (event.type) {
      case HistoryEventType.pumpStarted:
        icon = Icons.water_drop_rounded;
        iconColor = AppColors.primary;
        break;
      case HistoryEventType.pumpStopped:
        icon = Icons.stop_circle_rounded;
        iconColor = AppColors.textSecondary;
        break;
      case HistoryEventType.modeChanged:
        icon = Icons.tune_rounded;
        iconColor = AppColors.secondary;
        break;
      case HistoryEventType.robotMoved:
        icon = Icons.smart_toy_rounded;
        iconColor = AppColors.statusWet;
        break;
      case HistoryEventType.safetyWarning:
        icon = Icons.warning_amber_rounded;
        iconColor = AppColors.statusError;
        break;
      case HistoryEventType.error:
        icon = Icons.error_outline_rounded;
        iconColor = AppColors.statusError;
        break;
      case HistoryEventType.moistureReading:
        icon = Icons.eco_rounded;
        iconColor = AppColors.statusNormal;
        break;
    }

    final timeStr = DateFormat('HH:mm:ss').format(event.timestamp);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.surfaceBorder),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: iconColor.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: iconColor, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      event.title,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    Text(
                      timeStr,
                      style: const TextStyle(
                        fontSize: 11,
                        color: AppColors.textMuted,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  event.description,
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                    height: 1.3,
                  ),
                ),
                if (event.isDemo) ...[
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceElevated,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: const Text(
                      "DEMO MA'LUMOT",
                      style: TextStyle(
                        fontSize: 9,
                        color: AppColors.statusDry,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
