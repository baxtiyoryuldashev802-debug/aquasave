import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../core/theme/app_theme.dart';
import '../core/utils/moisture_calculator.dart';
import '../controllers/device_controller.dart';
import '../widgets/moisture_gauge.dart';
import '../widgets/emergency_stop_button.dart';
import '../widgets/demo_banner.dart';
import 'settings_screen.dart';

class HomeScreen extends StatelessWidget {
  final Function(int)? onNavigateToTab;

  const HomeScreen({super.key, this.onNavigateToTab});

  Widget _buildConnectionPill(DeviceConnectionState state, bool isDemo) {
    Color color;
    String label;
    IconData icon;

    if (isDemo) {
      color = AppColors.statusDry;
      label = "Demo";
      icon = Icons.science_outlined;
    } else {
      switch (state) {
        case DeviceConnectionState.connected:
          color = AppColors.connected;
          label = "Ulangan";
          icon = Icons.wifi_rounded;
          break;
        case DeviceConnectionState.connecting:
          color = AppColors.connecting;
          label = "Ulanmoqda...";
          icon = Icons.sync_rounded;
          break;
        case DeviceConnectionState.disconnected:
          color = AppColors.disconnected;
          label = "Uzilgan";
          icon = Icons.wifi_off_rounded;
          break;
        case DeviceConnectionState.sensorError:
          color = AppColors.statusError;
          label = "Datchik xatosi";
          icon = Icons.warning_amber_rounded;
          break;
        case DeviceConnectionState.staleData:
          color = AppColors.stale;
          label = "Eski ma'lumot";
          icon = Icons.history_rounded;
          break;
      }
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.4), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dev = context.watch<DeviceController>();
    final telemetry = dev.telemetry;
    final moisture = telemetry?.moisturePercent ?? 0;
    final state = MoistureCalculator.getState(moisture, dev.settings.moistureThresholdPercent);
    final lastFetchStr = dev.lastSuccessfulFetch != null
        ? DateFormat('HH:mm:ss').format(dev.lastSuccessfulFetch!)
        : "--:--:--";

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            DemoBanner(
              isDemoMode: dev.isDemoMode,
              onToggle: () => dev.toggleDemoMode(!dev.isDemoMode),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
                children: [
                  // Header
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [AppColors.primary, Color(0xFF047857)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(14),
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.primaryGlow,
                                  blurRadius: 10,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.eco_rounded,
                              color: Colors.black,
                              size: 26,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "AquaSave",
                                style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.textPrimary,
                                  letterSpacing: -0.5,
                                ),
                              ),
                              Text(
                                dev.settings.deviceName,
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: AppColors.textSecondary,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          _buildConnectionPill(dev.connectionState, dev.isDemoMode),
                          const SizedBox(width: 8),
                          IconButton(
                            icon: const Icon(Icons.settings_outlined, color: AppColors.textSecondary),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const SettingsScreen(),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // Main Soil Moisture Card
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: AppColors.surfaceBorder, width: 1),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.4),
                          blurRadius: 20,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              "Tuproq namligi",
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: AppColors.textPrimary,
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: AppColors.surfaceElevated,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                "Yangilandi: $lastFetchStr",
                                style: const TextStyle(
                                  fontSize: 11,
                                  color: AppColors.textMuted,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        MoistureGauge(
                          percentage: moisture,
                          state: state,
                          isStale: dev.isDataStale,
                          isValid: telemetry?.sensorValid ?? false,
                          size: 210,
                        ),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            _buildMiniSensorInfo(
                              "Sensor ADC",
                              telemetry != null ? "${telemetry.rawAdc}" : "--",
                              Icons.speed_rounded,
                            ),
                            _buildMiniSensorInfo(
                              "Chegara",
                              "${dev.settings.moistureThresholdPercent}%",
                              Icons.tune_rounded,
                            ),
                            _buildMiniSensorInfo(
                              "Signal",
                              telemetry?.wifiRssi != null ? "${telemetry!.wifiRssi} dBm" : "--",
                              Icons.wifi_rounded,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Device Status Grid
                  Row(
                    children: [
                      Expanded(
                        child: _buildStatusCard(
                          title: "Sug'orish nasosi",
                          value: telemetry?.pumpOn == true ? "Yoqilgan" : "O'chiq",
                          icon: Icons.water_damage_rounded,
                          active: telemetry?.pumpOn == true,
                          activeColor: AppColors.accentNeon,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildStatusCard(
                          title: "Tizim rejimi",
                          value: dev.settings.autoModeEnabled ? "Avtomatik" : "Qo'lda",
                          icon: Icons.auto_mode_rounded,
                          active: dev.settings.autoModeEnabled,
                          activeColor: AppColors.secondary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _buildStatusCard(
                          title: "Robot holati",
                          value: telemetry?.robotState ?? "STOPPED",
                          icon: Icons.precision_manufacturing_rounded,
                          active: (telemetry?.robotState ?? 'STOPPED') != 'STOPPED',
                          activeColor: AppColors.statusWet,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildStatusCard(
                          title: "Xavfsizlik taymeri",
                          value: "${dev.settings.maxPumpDurationSec}s limit",
                          icon: Icons.timer_outlined,
                          active: true,
                          activeColor: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // Quick Actions
                  const Text(
                    "Tezkor boshqaruv",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: _buildQuickActionButton(
                          label: telemetry?.pumpOn == true ? "Nasosni to'xtat" : "Sug'orish",
                          icon: telemetry?.pumpOn == true ? Icons.stop_circle_rounded : Icons.play_arrow_rounded,
                          color: telemetry?.pumpOn == true ? AppColors.statusDry : AppColors.primary,
                          onTap: () {
                            if (telemetry?.pumpOn == true) {
                              dev.stopPump();
                            } else {
                              dev.startPump();
                            }
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildQuickActionButton(
                          label: "Robotni haydash",
                          icon: Icons.sports_esports_rounded,
                          color: AppColors.secondary,
                          onTap: () => onNavigateToTab?.call(3), // Robot screen index
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  _buildQuickActionButton(
                    label: "AquaAI ovozli yordamchi",
                    icon: Icons.mic_rounded,
                    color: AppColors.primary,
                    isWide: true,
                    onTap: () => onNavigateToTab?.call(2), // AquaAI tab index
                  ),
                  const SizedBox(height: 24),

                  // Emergency Stop Button
                  EmergencyStopButton(
                    onStop: () => dev.emergencyStop(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMiniSensorInfo(String label, String value, IconData icon) {
    return Column(
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 13, color: AppColors.textMuted),
            const SizedBox(width: 4),
            Text(
              label,
              style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
      ],
    );
  }

  Widget _buildStatusCard({
    required String title,
    required String value,
    required IconData icon,
    required bool active,
    required Color activeColor,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: active ? activeColor.withOpacity(0.3) : AppColors.surfaceBorder,
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(
                icon,
                size: 20,
                color: active ? activeColor : AppColors.textMuted,
              ),
              Container(
                width: 7,
                height: 7,
                decoration: BoxDecoration(
                  color: active ? activeColor : AppColors.textMuted.withOpacity(0.4),
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            title,
            style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: active ? AppColors.textPrimary : AppColors.textMuted,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionButton({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
    bool isWide = false,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: AppColors.surfaceElevated,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.surfaceBorder, width: 1),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: AppColors.textPrimary,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
