import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_theme.dart';
import '../controllers/device_controller.dart';
import '../widgets/emergency_stop_button.dart';
import '../widgets/demo_banner.dart';

class RobotScreen extends StatelessWidget {
  const RobotScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final dev = context.watch<DeviceController>();
    final robotState = dev.telemetry?.robotState ?? 'STOPPED';
    final isMoving = robotState != 'STOPPED';

    return Scaffold(
      appBar: AppBar(
        title: const Text("Robot boshqaruvi"),
      ),
      body: SafeArea(
        child: Column(
          children: [
            DemoBanner(
              isDemoMode: dev.isDemoMode,
              onToggle: () => dev.toggleDemoMode(!dev.isDemoMode),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
                children: [
                  // Robot status card
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: AppColors.surface,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(
                        color: isMoving ? AppColors.accentNeon : AppColors.surfaceBorder,
                        width: isMoving ? 1.5 : 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 52,
                          height: 52,
                          decoration: BoxDecoration(
                            color: isMoving
                                ? AppColors.accentNeon.withOpacity(0.15)
                                : AppColors.surfaceBorder,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.smart_toy_outlined,
                            color: isMoving ? AppColors.accentNeon : AppColors.textMuted,
                            size: 28,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    "HOLAT: ",
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      color: AppColors.textMuted,
                                    ),
                                  ),
                                  Text(
                                    robotState,
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w800,
                                      color: isMoving ? AppColors.accentNeon : AppColors.textPrimary,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              const Text(
                                "Drayver: TB6612FNG Dual H-Bridge (PWM)",
                                style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // DIRECTIONAL D-PAD CONTROLLER
                  Center(
                    child: Container(
                      width: 280,
                      height: 280,
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        shape: BoxShape.circle,
                        border: Border.all(color: AppColors.surfaceBorder, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.5),
                            blurRadius: 24,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          // Center STOP indicator / button
                          GestureDetector(
                            onTap: () => dev.stopMoving(),
                            child: Container(
                              width: 80,
                              height: 80,
                              decoration: BoxDecoration(
                                color: AppColors.surfaceElevated,
                                shape: BoxShape.circle,
                                border: Border.all(color: AppColors.surfaceBorder, width: 2),
                              ),
                              child: const Center(
                                child: Text(
                                  "TO'XTA",
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w800,
                                    color: AppColors.textMuted,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ),
                            ),
                          ),

                          // UP (FORWARD)
                          Positioned(
                            top: 14,
                            child: _buildDPadButton(
                              icon: Icons.keyboard_arrow_up_rounded,
                              label: "Oldinga",
                              direction: 'FORWARD',
                              isActive: robotState == 'FORWARD',
                              dev: dev,
                            ),
                          ),

                          // DOWN (REVERSE)
                          Positioned(
                            bottom: 14,
                            child: _buildDPadButton(
                              icon: Icons.keyboard_arrow_down_rounded,
                              label: "Orqaga",
                              direction: 'REVERSE',
                              isActive: robotState == 'REVERSE',
                              dev: dev,
                            ),
                          ),

                          // LEFT (TURN LEFT)
                          Positioned(
                            left: 14,
                            child: _buildDPadButton(
                              icon: Icons.keyboard_arrow_left_rounded,
                              label: "Chapga",
                              direction: 'LEFT',
                              isActive: robotState == 'LEFT' || robotState == 'TURNING_LEFT',
                              dev: dev,
                            ),
                          ),

                          // RIGHT (TURN RIGHT)
                          Positioned(
                            right: 14,
                            child: _buildDPadButton(
                              icon: Icons.keyboard_arrow_right_rounded,
                              label: "O'ngga",
                              direction: 'RIGHT',
                              isActive: robotState == 'RIGHT' || robotState == 'TURNING_RIGHT',
                              dev: dev,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    "Boshqaruv usuli: Tugmani bosib turing — robot harakatlanadi; qo'yib yuborsangiz darhol to'xtaydi.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 12,
                      color: AppColors.textMuted,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Firmware safety note
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceElevated,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.surfaceBorder),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.security_rounded, size: 20, color: AppColors.primary),
                        SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            "Xavfsizlik: Aloqa uzilganda yoki 350ms ichida signal kelmasa, ESP32 drayveri motorlarni avtomatik to'xtatadi.",
                            style: TextStyle(fontSize: 12, color: AppColors.textSecondary, height: 1.3),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Emergency Stop Button
                  EmergencyStopButton(
                    onStop: () => dev.emergencyStop(),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDPadButton({
    required IconData icon,
    required String label,
    required String direction,
    required bool isActive,
    required DeviceController dev,
  }) {
    return GestureDetector(
      onTapDown: (_) => dev.startMoving(direction),
      onTapUp: (_) => dev.stopMoving(),
      onTapCancel: () => dev.stopMoving(),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        width: 64,
        height: 64,
        decoration: BoxDecoration(
          color: isActive ? AppColors.primary : AppColors.surfaceElevated,
          shape: BoxShape.circle,
          boxShadow: isActive
              ? [
                  BoxShadow(
                    color: AppColors.primaryGlow,
                    blurRadius: 16,
                  ),
                ]
              : [],
          border: Border.all(
            color: isActive ? AppColors.accentNeon : AppColors.surfaceBorder,
            width: 1.5,
          ),
        ),
        child: Icon(
          icon,
          color: isActive ? Colors.black : AppColors.textPrimary,
          size: 36,
        ),
      ),
    );
  }
}
