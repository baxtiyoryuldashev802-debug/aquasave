class TelemetryModel {
  final String deviceId;
  final int moisturePercent;
  final int rawAdc;
  final bool pumpOn;
  final String mode; // "AUTO" | "MANUAL"
  final String robotState; // "STOPPED" | "FORWARD" | "REVERSE" | "LEFT" | "RIGHT"
  final bool sensorValid;
  final DateTime timestamp;
  final int? batteryMv;
  final int? wifiRssi;
  final String? errorMessage;

  TelemetryModel({
    required this.deviceId,
    required this.moisturePercent,
    required this.rawAdc,
    required this.pumpOn,
    required this.mode,
    required this.robotState,
    required this.sensorValid,
    required this.timestamp,
    this.batteryMv,
    this.wifiRssi,
    this.errorMessage,
  });

  bool get isAutoMode => mode.toUpperCase() == 'AUTO';

  bool isStale(Duration threshold) {
    return DateTime.now().difference(timestamp) > threshold;
  }

  factory TelemetryModel.fromJson(Map<String, dynamic> json) {
    return TelemetryModel(
      deviceId: json['device_id']?.toString() ?? 'aquasave-01',
      moisturePercent: (json['moisture_percent'] as num?)?.toInt() ?? 0,
      rawAdc: (json['raw_adc'] as num?)?.toInt() ?? 0,
      pumpOn: json['pump_on'] == true,
      mode: json['mode']?.toString() ?? 'MANUAL',
      robotState: json['robot_state']?.toString() ?? 'STOPPED',
      sensorValid: json['sensor_valid'] == true,
      timestamp: json['timestamp'] != null
          ? DateTime.tryParse(json['timestamp'].toString()) ?? DateTime.now()
          : DateTime.now(),
      batteryMv: (json['battery_mv'] as num?)?.toInt(),
      wifiRssi: (json['wifi_rssi'] as num?)?.toInt(),
      errorMessage: json['error_message']?.toString(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'device_id': deviceId,
      'moisture_percent': moisturePercent,
      'raw_adc': rawAdc,
      'pump_on': pumpOn,
      'mode': mode,
      'robot_state': robotState,
      'sensor_valid': sensorValid,
      'timestamp': timestamp.toIso8601String(),
      'battery_mv': batteryMv,
      'wifi_rssi': wifiRssi,
      'error_message': errorMessage,
    };
  }

  TelemetryModel copyWith({
    String? deviceId,
    int? moisturePercent,
    int? rawAdc,
    bool? pumpOn,
    String? mode,
    String? robotState,
    bool? sensorValid,
    DateTime? timestamp,
    int? batteryMv,
    int? wifiRssi,
    String? errorMessage,
  }) {
    return TelemetryModel(
      deviceId: deviceId ?? this.deviceId,
      moisturePercent: moisturePercent ?? this.moisturePercent,
      rawAdc: rawAdc ?? this.rawAdc,
      pumpOn: pumpOn ?? this.pumpOn,
      mode: mode ?? this.mode,
      robotState: robotState ?? this.robotState,
      sensorValid: sensorValid ?? this.sensorValid,
      timestamp: timestamp ?? this.timestamp,
      batteryMv: batteryMv ?? this.batteryMv,
      wifiRssi: wifiRssi ?? this.wifiRssi,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }
}
