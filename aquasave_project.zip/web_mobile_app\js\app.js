/**
 * AQUASAVE — CORE APPLICATION CONTROLLER & LOGIC
 * High-performance mobile architecture for ESP32, AquaAI, and Smart Irrigation.
 */

const AquaSaveApp = (() => {
  // --- APPLICATION STATE ---
  const state = {
    isDemoMode: true,
    connectionState: 'demo', // 'connected' | 'demo' | 'disconnected' | 'stale'
    telemetry: {
      deviceId: 'aquasave-demo-01',
      moisturePercent: 35,
      rawAdc: 2250,
      pumpOn: false,
      mode: 'MANUAL',
      robotState: 'STOPPED',
      sensorValid: true,
      batteryMv: 4180,
      wifiRssi: -55,
      timestamp: Date.now()
    },
    settings: {
      deviceName: 'AquaSave Bot 01',
      esp32Ip: '192.168.4.1',
      esp32Port: 80,
      autoModeEnabled: false,
      thresholdPercent: 35,
      hysteresisPercent: 5,
      maxPumpSec: 30,
      dryAdc: 3100,
      wetAdc: 1400,
      aiProxyUrl: 'http://localhost:3000/api/ai/chat'
    },
    history: [
      { id: 1, type: 'pump', title: "Sug'orish amalga oshirildi", desc: "15s davomida nasos ishladi", time: "11:42", demo: true },
      { id: 2, type: 'mode', title: "Rejim o'zgartirildi", desc: "Qo'lda boshqaruv faollashtirildi", time: "10:15", demo: true },
      { id: 3, type: 'sensor', title: "Datchik kalibrlandi", desc: "2-nuqtali o'lchov saqlandi", time: "09:30", demo: true }
    ],
    chartData: [38, 36, 35, 34, 32, 30, 29, 28, 55, 52, 48, 45, 42, 39, 36, 35],
    manualPumpDuration: 15,
    speechEnabled: true,
    isListening: false,
    movementTimer: null,
    telemetryTimer: null,
    pumpCountdownTimer: null
  };

  // --- INITIALIZATION ---
  function init() {
    registerServiceWorker();
    setupPwaInstall();
    setupNavigation();
    setupEventListeners();
    setupVoiceAssistant();
    startTelemetryLoop();
    drawMoistureChart();
    renderUI();
    if (window.lucide) {
      lucide.createIcons();
    }
  }

  // --- SERVICE WORKER & PWA INSTALL ---
  let deferredPrompt = null;
  function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/service-worker.js')
        .then(() => console.log('[PWA] Service Worker muvaffaqiyatli ro\'yxatga olindi'))
        .catch(err => console.log('[PWA] Service Worker xatosi:', err));
    }
  }

  function setupPwaInstall() {
    const installBtn = document.getElementById('install-pwa-btn');
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e;
      if (installBtn) installBtn.style.display = 'inline-flex';
    });

    installBtn?.addEventListener('click', async () => {
      if (deferredPrompt) {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') {
          installBtn.style.display = 'none';
        }
        deferredPrompt = null;
      } else {
        // iOS or already installed guidance
        const isIos = /iphone|ipad|ipod/.test(window.navigator.userAgent.toLowerCase());
        if (isIos) {
          alert("iOS (iPhone/iPad) da o'rnatish uchun:\n1. Safari pastidagi 'Ulashish' (Share) tugmasini bosing.\n2. 'Bosh ekranga qo'shish' (Add to Home Screen) bandini tanlang.\nIlova to'liq ekranda alohida o'rnatiladi!");
        } else {
          alert("Android telefonda o'rnatish uchun:\nBrauzer menyusidan (3 nuqta) 'Ilovani o'rnatish' (Install app) yoki 'Bosh ekranga qo'shish' bandini tanlang.");
        }
      }
    });
  }

  // --- NAVIGATION CONTROLLER ---
  function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
      item.addEventListener('click', () => {
        const targetId = item.getAttribute('data-target');
        document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

        document.getElementById(targetId)?.classList.add('active');
        item.classList.add('active');

        if (targetId === 'screen-history') {
          setTimeout(drawMoistureChart, 100);
        }
        if (window.lucide) lucide.createIcons();
      });
    });

    // Quick Action shortcuts from Home screen
    document.getElementById('quick-robot-btn')?.addEventListener('click', () => {
      document.querySelector('[data-target="screen-robot"]')?.click();
    });
    document.getElementById('quick-ai-btn')?.addEventListener('click', () => {
      document.querySelector('[data-target="screen-aquaai"]')?.click();
    });
  }

  // --- EVENT LISTENERS & CONTROLS ---
  function setupEventListeners() {
    // Demo Mode toggle
    const toggleBannerBtn = document.getElementById('toggle-mode-btn');
    const settingsDemoToggle = document.getElementById('settings-demo-toggle');
    
    toggleBannerBtn?.addEventListener('click', () => {
      setDemoMode(!state.isDemoMode);
    });
    settingsDemoToggle?.addEventListener('change', (e) => {
      setDemoMode(e.target.checked);
    });

    // Settings Modal
    document.getElementById('open-settings-btn')?.addEventListener('click', () => {
      document.getElementById('settings-modal')?.classList.remove('hidden');
    });
    document.getElementById('close-settings-btn')?.addEventListener('click', () => {
      document.getElementById('settings-modal')?.classList.add('hidden');
    });

    // Ping Test
    document.getElementById('test-ping-btn')?.addEventListener('click', testPing);

    // Auto Mode & Threshold Controls
    const autoToggle = document.getElementById('auto-mode-toggle');
    autoToggle?.addEventListener('change', (e) => {
      setAutoMode(e.target.checked);
    });

    const thresholdRange = document.getElementById('threshold-range');
    thresholdRange?.addEventListener('input', (e) => {
      state.settings.thresholdPercent = parseInt(e.target.value);
      document.getElementById('threshold-val-text').textContent = e.target.value + '%';
      document.getElementById('metric-threshold').textContent = e.target.value + '%';
      updateAutoReason();
    });

    const hysteresisRange = document.getElementById('hysteresis-range');
    hysteresisRange?.addEventListener('input', (e) => {
      state.settings.hysteresisPercent = parseInt(e.target.value);
      document.getElementById('hysteresis-val-text').textContent = '+' + e.target.value + '%';
      updateAutoReason();
    });

    // Manual Pump Duration
    const manualDurationRange = document.getElementById('manual-duration-range');
    manualDurationRange?.addEventListener('input', (e) => {
      state.manualPumpDuration = parseInt(e.target.value);
      document.getElementById('manual-duration-text').textContent = e.target.value + ' soniya';
    });

    // Pump buttons
    document.getElementById('quick-pump-btn')?.addEventListener('click', togglePump);
    document.getElementById('manual-start-pump')?.addEventListener('click', () => startPump(state.manualPumpDuration));
    document.getElementById('manual-stop-pump')?.addEventListener('click', stopPump);
    document.getElementById('emergency-stop-btn')?.addEventListener('click', emergencyStop);

    // Robot D-Pad Controls (Press and Hold with Stop on Release)
    setupDPad();

    // Calibration buttons
    document.getElementById('calib-dry-btn')?.addEventListener('click', () => {
      state.settings.dryAdc = state.telemetry.rawAdc;
      document.getElementById('val-dry-adc').textContent = state.settings.dryAdc;
      showFeedbackPill("Quruq ADC saqlandi: " + state.settings.dryAdc);
    });
    document.getElementById('calib-wet-btn')?.addEventListener('click', () => {
      state.settings.wetAdc = state.telemetry.rawAdc;
      document.getElementById('val-wet-adc').textContent = state.settings.wetAdc;
      showFeedbackPill("Nam ADC saqlandi: " + state.settings.wetAdc);
    });

    // History filter tabs
    document.querySelectorAll('.filter-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
      });
    });
  }

  // --- ROBOT D-PAD CONTROLLER ---
  function setupDPad() {
    const dpadButtons = document.querySelectorAll('.dpad-btn');
    dpadButtons.forEach(btn => {
      const dir = btn.getAttribute('data-dir');

      const handlePress = (e) => {
        e.preventDefault();
        btn.classList.add('active');
        startMoving(dir);
      };

      const handleRelease = (e) => {
        e.preventDefault();
        btn.classList.remove('active');
        stopMoving();
      };

      btn.addEventListener('mousedown', handlePress);
      btn.addEventListener('mouseup', handleRelease);
      btn.addEventListener('mouseleave', handleRelease);

      btn.addEventListener('touchstart', handlePress, { passive: false });
      btn.addEventListener('touchend', handleRelease, { passive: false });
      btn.addEventListener('touchcancel', handleRelease, { passive: false });
    });

    document.getElementById('dpad-center-stop')?.addEventListener('click', () => {
      stopMoving();
    });
  }

  function startMoving(direction) {
    state.telemetry.robotState = direction;
    updateRobotUI();

    if (state.isDemoMode) return;

    // Send HTTP command with 200ms heartbeat
    sendEsp32Command('MOVE_' + direction, { heartbeat_ms: 350 });
    clearInterval(state.movementTimer);
    state.movementTimer = setInterval(() => {
      sendEsp32Command('MOVE_' + direction, { heartbeat_ms: 350 });
    }, 200);
  }

  function stopMoving() {
    clearInterval(state.movementTimer);
    state.movementTimer = null;
    state.telemetry.robotState = 'STOPPED';
    updateRobotUI();

    if (!state.isDemoMode) {
      sendEsp32Command('STOP_MOVEMENT', {});
    }
  }

  function updateRobotUI() {
    const stateEl = document.getElementById('robot-live-state');
    const tileVal = document.getElementById('tile-robot-val');
    const tileDot = document.getElementById('tile-robot-dot');

    if (stateEl) stateEl.textContent = state.telemetry.robotState;
    if (tileVal) tileVal.textContent = state.telemetry.robotState;
    if (tileDot) {
      if (state.telemetry.robotState !== 'STOPPED') {
        tileDot.classList.add('active');
      } else {
        tileDot.classList.remove('active');
      }
    }
  }

  // --- IRRIGATION PUMP LOGIC ---
  function togglePump() {
    if (state.telemetry.pumpOn) {
      stopPump();
    } else {
      startPump(state.manualPumpDuration);
    }
  }

  function startPump(durationSec) {
    const duration = durationSec || 15;
    state.telemetry.pumpOn = true;
    updatePumpUI();

    addHistoryEvent('pump', "Sug'orish boshlandi" + (state.isDemoMode ? " (Demo)" : ""), `Nasos ${duration} soniyaga yoqildi`, state.isDemoMode);
    showFeedbackPill(`Nasos ${duration} soniyaga yoqildi`);

    if (state.isDemoMode) {
      clearTimeout(state.pumpCountdownTimer);
      state.pumpCountdownTimer = setTimeout(() => {
        stopPump();
      }, duration * 1000);
      return;
    }

    sendEsp32Command('START_WATER', { duration_sec: duration }).then(res => {
      if (!res || res.status === 'rejected') {
        state.telemetry.pumpOn = false;
        updatePumpUI();
        showFeedbackPill("ESP32 buyruqni rad etdi!");
      }
    });
  }

  function stopPump() {
    clearTimeout(state.pumpCountdownTimer);
    state.telemetry.pumpOn = false;
    updatePumpUI();

    addHistoryEvent('pump', "Sug'orish to'xtatildi" + (state.isDemoMode ? " (Demo)" : ""), "Nasos o'chirildi", state.isDemoMode);
    showFeedbackPill("Nasos to'xtatildi");

    if (!state.isDemoMode) {
      sendEsp32Command('STOP_WATER', {});
    }
  }

  function updatePumpUI() {
    const isPump = state.telemetry.pumpOn;
    const banner = document.getElementById('pump-indicator-card');
    const bannerStatus = document.getElementById('pump-banner-status');
    const bannerDesc = document.getElementById('pump-banner-desc');
    const quickPumpBtn = document.getElementById('quick-pump-btn');
    const tilePumpVal = document.getElementById('tile-pump-val');
    const tilePumpDot = document.getElementById('tile-pump-dot');

    if (isPump) {
      banner?.classList.remove('off');
      if (bannerStatus) bannerStatus.textContent = "NASOS ISHLAMOQDA";
      if (bannerDesc) bannerDesc.textContent = "ESP32 relesi faol. Suv purkash davom etmoqda.";
      if (quickPumpBtn) {
        quickPumpBtn.innerHTML = '<i data-lucide="square" class="btn-icon"></i><span>To\'xtatish</span>';
        quickPumpBtn.className = 'action-btn btn-danger';
      }
      if (tilePumpVal) tilePumpVal.textContent = "Yoqilgan";
      if (tilePumpDot) tilePumpDot.classList.add('active');
    } else {
      banner?.classList.add('off');
      if (bannerStatus) bannerStatus.textContent = "NASOS TO'XTAGAN";
      if (bannerDesc) bannerDesc.textContent = "Nasos o'chiq holatda. Bosim normal.";
      if (quickPumpBtn) {
        quickPumpBtn.innerHTML = '<i data-lucide="play" class="btn-icon"></i><span>Sug\'orish</span>';
        quickPumpBtn.className = 'action-btn btn-primary';
      }
      if (tilePumpVal) tilePumpVal.textContent = "O'chiq";
      if (tilePumpDot) tilePumpDot.classList.remove('active');
    }
    if (window.lucide) lucide.createIcons();
  }

  function setAutoMode(enabled) {
    state.settings.autoModeEnabled = enabled;
    state.telemetry.mode = enabled ? 'AUTO' : 'MANUAL';
    document.getElementById('tile-mode-val').textContent = enabled ? "Avtomatik" : "Qo'lda";
    updateAutoReason();

    addHistoryEvent('mode', enabled ? "Avtomatik rejim yoqildi" : "Qo'lda rejimga o'tildi", `Chegara: ${state.settings.thresholdPercent}%`, state.isDemoMode);

    if (!state.isDemoMode) {
      sendEsp32Command(enabled ? 'SET_AUTO_MODE' : 'SET_MANUAL_MODE', {
        threshold: state.settings.thresholdPercent,
        hysteresis: state.settings.hysteresisPercent
      });
    }
  }

  function updateAutoReason() {
    const box = document.getElementById('auto-reason-box');
    if (!box) return;
    const { autoModeEnabled, thresholdPercent, hysteresisPercent } = state.settings;
    const { moisturePercent, sensorValid } = state.telemetry;

    if (!autoModeEnabled) {
      box.textContent = "Avtomatik rejim o'chiq. Tizim faqat qo'lda buyruqlarni qabul qiladi.";
    } else if (!sensorValid) {
      box.textContent = "Sensor xatosi: Datchikdan aniq ma'lumot kelmayapti. Xavfsizlik uchun to'xtatilgan.";
    } else if (moisturePercent <= thresholdPercent) {
      box.textContent = `Namlik (${moisturePercent}%) belgilangan chegaradan (${thresholdPercent}%) past. Sug'orish faollashtirildi!`;
    } else if (moisturePercent < thresholdPercent + hysteresisPercent) {
      box.textContent = `Gisterezis oralig'ida (${thresholdPercent}% - ${thresholdPercent + hysteresisPercent}%). Nasos tez-tez o'chib-yonishidan saqlanmoqda.`;
    } else {
      box.textContent = `Namlik (${moisturePercent}%) yetarli darajada. Sug'orish talab etilmaydi.`;
    }
  }

  // --- EMERGENCY STOP ---
  function emergencyStop() {
    stopMoving();
    clearTimeout(state.pumpCountdownTimer);
    state.telemetry.pumpOn = false;
    state.telemetry.robotState = 'STOPPED';
    updatePumpUI();
    updateRobotUI();

    addHistoryEvent('danger', "FAVQULODDA TO'XTATISH" + (state.isDemoMode ? " (Demo)" : ""), "Barcha motorlar va suv ta'minoti majburiy to'xtatildi", state.isDemoMode);
    alert("XAVFSIZLIK TIZIMI: Barcha motorlar va sug'orish nasosi majburiy to'xtatildi!");

    if (!state.isDemoMode) {
      sendEsp32Command('STOP_ALL', {});
    }
  }

  // --- TELEMETRY & SENSOR MATH LOOP ---
  function startTelemetryLoop() {
    clearInterval(state.telemetryTimer);
    state.telemetryTimer = setInterval(async () => {
      if (state.isDemoMode) {
        simulateDemoTelemetry();
      } else {
        await fetchRealTelemetry();
      }
      renderUI();
    }, 1000);
  }

  function simulateDemoTelemetry() {
    // Dynamic plant moisture physics:
    // If pump is on, moisture rises; otherwise it slowly dries out
    if (state.telemetry.pumpOn) {
      state.telemetry.moisturePercent = Math.min(95, state.telemetry.moisturePercent + 2);
    } else {
      state.telemetry.moisturePercent = Math.max(15, +(state.telemetry.moisturePercent - 0.05).toFixed(1));
    }

    // Auto Mode trigger simulation
    if (state.settings.autoModeEnabled && !state.telemetry.pumpOn) {
      if (state.telemetry.moisturePercent <= state.settings.thresholdPercent) {
        startPump(10);
      }
    }

    state.telemetry.rawAdc = 2200 + Math.floor(Math.random() * 40);
    state.telemetry.timestamp = Date.now();
    state.connectionState = 'demo';
  }

  async function fetchRealTelemetry() {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2500);

      const res = await fetch(`http://${state.settings.esp32Ip}:${state.settings.esp32Port}/api/telemetry`, {
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (res.ok) {
        const data = await res.json();
        state.telemetry.moisturePercent = data.moisture_percent;
        state.telemetry.rawAdc = data.raw_adc;
        state.telemetry.pumpOn = data.pump_on;
        state.telemetry.mode = data.mode;
        state.telemetry.robotState = data.robot_state;
        state.telemetry.sensorValid = data.sensor_valid;
        state.telemetry.wifiRssi = data.wifi_rssi;
        state.telemetry.timestamp = Date.now();
        state.connectionState = 'connected';
      } else {
        state.connectionState = 'disconnected';
      }
    } catch (_) {
      state.connectionState = 'disconnected';
    }
  }

  async function sendEsp32Command(action, params) {
    try {
      const payload = {
        command_id: 'CMD_' + Date.now(),
        action: action,
        params: params,
        timestamp: new Date().toISOString()
      };

      const res = await fetch(`http://${state.settings.esp32Ip}:${state.settings.esp32Port}/api/command`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      return await res.json();
    } catch (e) {
      console.warn("ESP32 aloqa xatosi:", e);
      return null;
    }
  }

  async function testPing() {
    const statusEl = document.getElementById('ping-status-text');
    if (!statusEl) return;
    statusEl.textContent = "Tekshirilmoqda...";

    if (state.isDemoMode) {
      setTimeout(() => {
        statusEl.innerHTML = "<span class='text-mint'>Demo simulyatsiya: 14 ms</span>";
      }, 400);
      return;
    }

    const start = Date.now();
    try {
      const res = await fetch(`http://${state.settings.esp32Ip}:${state.settings.esp32Port}/api/status`, {
        signal: AbortSignal.timeout(2000)
      });
      const latency = Date.now() - start;
      if (res.ok) {
        statusEl.innerHTML = `<span class='text-mint'>Aloqa a'lo darajada: ${latency} ms</span>`;
      } else {
        statusEl.innerHTML = `<span style='color:var(--status-danger)'>Xato: HTTP ${res.status}</span>`;
      }
    } catch (err) {
      statusEl.innerHTML = "<span style='color:var(--status-danger)'>ESP32 ga ulanib bo'lmadi (Timeout)</span>";
    }
  }

  // --- UI RENDERER & GAUGES ---
  function renderUI() {
    const { moisturePercent, rawAdc, wifiRssi, timestamp } = state.telemetry;

    // 1. Connection Pill
    const pill = document.getElementById('connection-pill');
    const pillText = document.getElementById('connection-text');
    if (pill && pillText) {
      pill.className = 'status-pill status-' + state.connectionState;
      if (state.connectionState === 'demo') pillText.textContent = 'Demo';
      else if (state.connectionState === 'connected') pillText.textContent = 'Ulangan';
      else pillText.textContent = 'Uzilgan';
    }

    // 2. Moisture Percent & State Badge
    const moistureVal = document.getElementById('moisture-val');
    const stateBadge = document.getElementById('moisture-state-badge');
    const stateText = document.getElementById('moisture-state-text');
    const timeBadge = document.getElementById('last-updated-badge');

    const m = Math.round(moisturePercent);
    if (moistureVal) moistureVal.textContent = m + '%';

    let stateClass = 'state-normal';
    let label = "Me'yorida";
    if (m < state.settings.thresholdPercent) {
      stateClass = 'state-dry';
      label = 'Quruq';
    } else if (m > 75) {
      stateClass = 'state-wet';
      label = 'Nam';
    }

    if (stateBadge) {
      stateBadge.className = 'moisture-badge ' + stateClass;
    }
    if (stateText) stateText.textContent = label;

    if (timeBadge) {
      const d = new Date(timestamp);
      timeBadge.textContent = 'Yangilandi: ' + d.toLocaleTimeString();
    }

    // 3. Circular SVG Arc Calculation
    // Total perimeter = 2 * PI * 82 ≈ 515.2px.
    // Full arc = 270deg (3/4 of 515.2 ≈ 386.4px)
    const arcLength = 515.2 * 0.75;
    const progress = (m / 100) * arcLength;
    const offset = 515.2 - progress;

    const fillArc = document.getElementById('gauge-fill');
    const glowArc = document.getElementById('gauge-glow');
    if (fillArc) fillArc.style.strokeDashoffset = offset;
    if (glowArc) glowArc.style.strokeDashoffset = offset;

    // 4. Metrics Grid
    const mAdc = document.getElementById('metric-adc');
    const mRssi = document.getElementById('metric-rssi');
    const calibAdc = document.getElementById('calib-current-adc');
    if (mAdc) mAdc.textContent = rawAdc;
    if (mRssi) mRssi.textContent = wifiRssi + ' dBm';
    if (calibAdc) calibAdc.textContent = rawAdc;
  }

  function setDemoMode(val) {
    state.isDemoMode = val;
    const banner = document.getElementById('demo-banner');
    if (val) {
      banner?.classList.remove('hidden');
      state.connectionState = 'demo';
    } else {
      banner?.classList.add('hidden');
      state.connectionState = 'disconnected';
    }
    document.getElementById('settings-demo-toggle').checked = val;
    renderUI();
  }

  function showFeedbackPill(text) {
    const fb = document.getElementById('pump-cmd-feedback');
    if (fb) {
      fb.textContent = text;
      fb.classList.remove('hidden');
      setTimeout(() => fb.classList.add('hidden'), 3500);
    }
  }

  // --- HISTORY & EVENT LOGGING ---
  function addHistoryEvent(type, title, desc, demo = false) {
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    state.history.unshift({ id: Date.now(), type, title, desc, time, demo });
    if (state.history.length > 50) state.history.pop();
    renderHistoryTimeline();
  }

  function renderHistoryTimeline() {
    const container = document.getElementById('events-timeline');
    if (!container) return;
    container.innerHTML = state.history.map(item => `
      <div class="timeline-item">
        <div class="timeline-icon-box">
          <i data-lucide="${item.type === 'pump' ? 'droplet' : item.type === 'mode' ? 'sliders' : item.type === 'danger' ? 'alert-triangle' : 'activity'}"></i>
        </div>
        <div class="timeline-details">
          <div class="timeline-head">
            <span>${item.title}</span>
            <span class="timeline-time">${item.time}</span>
          </div>
          <div class="timeline-desc">${item.desc}</div>
          ${item.demo ? '<span class="demo-tag">DEMO MA\'LUMOT</span>' : ''}
        </div>
      </div>
    `).join('');
    if (window.lucide) lucide.createIcons();
  }

  function drawMoistureChart() {
    const canvas = document.getElementById('moisture-chart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;

    ctx.clearRect(0, 0, w, h);

    // Draw grid lines
    ctx.strokeStyle = '#1C2E24';
    ctx.lineWidth = 1;
    for (let y = 30; y < h; y += 30) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    const data = state.chartData;
    const step = w / (data.length - 1);

    // Gradient fill under curve
    const gradient = ctx.createLinearGradient(0, 0, 0, h);
    gradient.addColorStop(0, 'rgba(16, 185, 129, 0.35)');
    gradient.addColorStop(1, 'rgba(16, 185, 129, 0.0)');

    ctx.beginPath();
    data.forEach((val, i) => {
      const x = i * step;
      const y = h - (val / 100) * (h - 20) - 10;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.lineTo(w, h);
    ctx.lineTo(0, h);
    ctx.closePath();
    ctx.fillStyle = gradient;
    ctx.fill();

    // Line stroke
    ctx.beginPath();
    data.forEach((val, i) => {
      const x = i * step;
      const y = h - (val / 100) * (h - 20) - 10;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = '#10B981';
    ctx.lineWidth = 2.5;
    ctx.stroke();
  }

  // --- AQUAAI VOICE ASSISTANT ---
  function setupVoiceAssistant() {
    const micBtn = document.getElementById('mic-trigger-btn');
    const sendBtn = document.getElementById('ai-send-btn');
    const textInput = document.getElementById('ai-text-input');
    const voiceIndicator = document.getElementById('voice-indicator');
    const cancelVoiceBtn = document.getElementById('cancel-voice-btn');
    const ttsToggle = document.getElementById('ai-tts-toggle');

    ttsToggle?.addEventListener('click', () => {
      state.speechEnabled = !state.speechEnabled;
      ttsToggle.classList.toggle('active', state.speechEnabled);
    });

    let recognition = null;
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognition = new SpeechRecognition();
      recognition.lang = 'uz-UZ';
      recognition.continuous = false;
      recognition.interimResults = true;

      recognition.onstart = () => {
        state.isListening = true;
        micBtn?.classList.add('listening');
        voiceIndicator?.classList.remove('hidden');
        document.getElementById('transcription-text').textContent = "Eshitmoqdaman... (O'zbek tilida gapiring)";
      };

      recognition.onresult = (event) => {
        const transcript = Array.from(event.results)
          .map(r => r[0].transcript)
          .join('');
        document.getElementById('transcription-text').textContent = transcript;
        textInput.value = transcript;
      };

      recognition.onerror = () => {
        stopVoiceRecognition();
      };

      recognition.onend = () => {
        stopVoiceRecognition();
        if (textInput.value.trim()) {
          submitAiQuery(textInput.value.trim());
          textInput.value = '';
        }
      };
    }

    function stopVoiceRecognition() {
      state.isListening = false;
      micBtn?.classList.remove('listening');
      voiceIndicator?.classList.add('hidden');
      if (recognition) recognition.stop();
    }

    micBtn?.addEventListener('click', () => {
      if (state.isListening) {
        stopVoiceRecognition();
      } else {
        if (recognition) {
          recognition.start();
        } else {
          alert("Ushbu brauzerda Web Speech API qo'llab-quvvatlanmaydi. Matn orqali kiriting.");
        }
      }
    });

    cancelVoiceBtn?.addEventListener('click', stopVoiceRecognition);

    sendBtn?.addEventListener('click', () => {
      if (textInput.value.trim()) {
        submitAiQuery(textInput.value.trim());
        textInput.value = '';
      }
    });

    textInput?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && textInput.value.trim()) {
        submitAiQuery(textInput.value.trim());
        textInput.value = '';
      }
    });

    // Chips click
    document.querySelectorAll('.prompt-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const query = chip.getAttribute('data-query');
        submitAiQuery(query);
      });
    });
  }

  async function submitAiQuery(userText) {
    appendChatMessage(userText, true);

    // Call OpenAI proxy or fallback agronomist logic
    try {
      const res = await fetch(state.settings.aiProxyUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userText,
          current_telemetry: state.telemetry,
          is_demo_mode: state.isDemoMode
        })
      });

      if (res.ok) {
        const data = await res.json();
        handleAiResponse(data);
      } else {
        fallbackUzbekAi(userText);
      }
    } catch (_) {
      fallbackUzbekAi(userText);
    }
  }

  function handleAiResponse(data) {
    const responseText = data.natural_response || "Buyruq qabul qilindi.";
    appendChatMessage(responseText, false, data);

    if (state.speechEnabled && 'speechSynthesis' in window) {
      speakText(responseText);
    }

    if (data.action && !data.requires_confirmation && data.action !== 'NONE') {
      executeAction(data.action, data.params);
    }
  }

  function fallbackUzbekAi(userText) {
    const lower = userText.toLowerCase();
    let text = "";
    let action = 'NONE';
    let requiresConfirm = false;

    if (lower.includes('namlik') || lower.includes('tuproq')) {
      const m = Math.round(state.telemetry.moisturePercent);
      text = `Hozirgi tuproq namligi: ${m}%. ` + (m < 35 ? "Tuproq quruq, sug'orish tavsiya etiladi." : "Tuproq namligi me'yorida.");
      action = 'GET_MOISTURE';
    } else if (lower.includes("sug'orish") || lower.includes("suv")) {
      text = "Sug'orish nasosini 15 soniyaga yoqishga tayyorman.";
      action = 'START_WATER';
      requiresConfirm = true;
    } else if (lower.includes("to'xtat") || lower.includes("to'xta")) {
      text = "Barcha harakat va sug'orish to'xtatildi.";
      action = 'STOP_ALL';
      emergencyStop();
    } else if (lower.includes("oldinga")) {
      text = "Robot 1 soniya oldinga harakatlanmoqda.";
      action = 'MOVE_FORWARD';
      startMoving('FORWARD');
      setTimeout(stopMoving, 1000);
    } else {
      text = "Sizni tushundim. Masalan, 'Tuproq namligi qancha?' yoki 'Sug'orishni boshla' deb buyruq berishingiz mumkin.";
    }

    const data = {
      action,
      natural_response: text,
      requires_confirmation: requiresConfirm,
      confirmation_prompt: requiresConfirm ? "Haqiqatan ham nasosni yoqasizmi?" : null
    };
    appendChatMessage(text, false, data);

    if (state.speechEnabled && 'speechSynthesis' in window) {
      speakText(text);
    }
  }

  function appendChatMessage(text, isUser, actionData = null) {
    const list = document.getElementById('ai-messages-list');
    if (!list) return;

    const bubble = document.createElement('div');
    bubble.className = 'msg-bubble ' + (isUser ? 'msg-user' : 'msg-bot');
    
    let html = `<p>${text}</p>`;
    if (actionData && actionData.requires_confirmation && actionData.action) {
      html += `
        <div class="msg-action-card">
          <p style="font-size:12px;margin-bottom:6px;color:var(--accent-secondary)">${actionData.confirmation_prompt || "Ushbu amalni tasdiqlaysizmi?"}</p>
          <button onclick="AquaSaveApp.confirmAiAction('${actionData.action}')">Tasdiqlash</button>
        </div>
      `;
    }

    bubble.innerHTML = html;
    list.appendChild(bubble);
    list.scrollTop = list.scrollHeight;
  }

  function executeAction(action, params) {
    if (action === 'START_WATER') {
      startPump(params?.duration_sec || 15);
    } else if (action === 'STOP_WATER') {
      stopPump();
    } else if (action === 'SET_AUTO_MODE') {
      setAutoMode(true);
    } else if (action === 'SET_MANUAL_MODE') {
      setAutoMode(false);
    } else if (action === 'MOVE_FORWARD') {
      startMoving('FORWARD');
      setTimeout(stopMoving, 1000);
    } else if (action === 'MOVE_REVERSE') {
      startMoving('REVERSE');
      setTimeout(stopMoving, 1000);
    } else if (action === 'TURN_LEFT') {
      startMoving('LEFT');
      setTimeout(stopMoving, 600);
    } else if (action === 'TURN_RIGHT') {
      startMoving('RIGHT');
      setTimeout(stopMoving, 600);
    } else if (action === 'STOP_ALL') {
      emergencyStop();
    }
  }

  function speakText(text) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'uz-UZ';
    utterance.rate = 1.0;
    window.speechSynthesis.speak(utterance);
  }

  return {
    init,
    emergencyStop,
    confirmAiAction: (act) => {
      executeAction(act, {});
      appendChatMessage("Buyruq tasdiqlandi va bajarildi.", false);
    }
  };
})();

document.addEventListener('DOMContentLoaded', AquaSaveApp.init);
