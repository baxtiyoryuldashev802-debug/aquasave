import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../constants/app_constants.dart';
import '../../models/telemetry_model.dart';
import '../../models/command_model.dart';
import '../../models/device_settings_model.dart';

class Esp32Client {
  String host;
  int port;
  final http.Client _httpClient;

  Esp32Client({
    this.host = AppConstants.defaultEsp32Ip,
    this.port = AppConstants.defaultEsp32Port,
    http.Client? httpClient,
  }) : _httpClient = httpClient ?? http.Client();

  Uri _buildUri(String path) {
    return Uri.parse('http://$host:$port$path');
  }

  /// Fetches real-time telemetry from ESP32
  Future<TelemetryModel> fetchTelemetry() async {
    final uri = _buildUri('/api/telemetry');
    try {
      final response = await _httpClient.get(uri).timeout(AppConstants.commandTimeout);
      if (response.statusCode == 200) {
        final Map<String, dynamic> data = jsonDecode(response.body);
        return TelemetryModel.fromJson(data);
      } else {
        throw Exception("ESP32 javob kodi: ${response.statusCode}");
      }
    } catch (e) {
      throw Exception("ESP32 bilan aloqa o'rnatib bo'lmadi: $e");
    }
  }

  /// Sends a structured command to ESP32
  Future<CommandModel> sendCommand(CommandModel command) async {
    final uri = _buildUri('/api/command');
    try {
      final body = jsonEncode(command.toJson());
      final response = await _httpClient
          .post(
            uri,
            headers: {'Content-Type': 'application/json'},
            body: body,
          )
          .timeout(AppConstants.commandTimeout);

      if (response.statusCode == 200) {
        final Map<String, dynamic> resData = jsonDecode(response.body);
        final statusStr = resData['status']?.toString().toLowerCase();
        CommandStatus status;
        if (statusStr == 'accepted' || statusStr == 'ok') {
          status = CommandStatus.accepted;
        } else if (statusStr == 'completed') {
          status = CommandStatus.completed;
        } else if (statusStr == 'rejected') {
          status = CommandStatus.rejected;
        } else {
          status = CommandStatus.error;
        }

        return command.copyWith(
          status: status,
          message: resData['message']?.toString(),
        );
      } else {
        return command.copyWith(
          status: CommandStatus.rejected,
          message: "ESP32 xatoligi: ${response.statusCode}",
        );
      }
    } on TimeoutException {
      return command.copyWith(
        status: CommandStatus.timeout,
        message: "Buyruq vaqti tugadi (Timeout)",
      );
    } catch (e) {
      return command.copyWith(
        status: CommandStatus.error,
        message: "Ulanish xatosi: $e",
      );
    }
  }

  /// Updates settings on ESP32
  Future<bool> updateSettings(DeviceSettingsModel settings) async {
    final uri = _buildUri('/api/settings');
    try {
      final body = jsonEncode(settings.toJson());
      final response = await _httpClient
          .post(
            uri,
            headers: {'Content-Type': 'application/json'},
            body: body,
          )
          .timeout(AppConstants.commandTimeout);
      return response.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  /// Pings ESP32 to test connection and latency
  Future<int?> ping() async {
    final stopwatch = Stopwatch()..start();
    try {
      final uri = _buildUri('/api/status');
      final response = await _httpClient.get(uri).timeout(const Duration(seconds: 2));
      stopwatch.stop();
      if (response.statusCode == 200) {
        return stopwatch.elapsedMilliseconds;
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  void dispose() {
    _httpClient.close();
  }
}
