import 'package:flutter_test/flutter_test.dart';
import '../lib/core/constants/app_constants.dart';
import '../lib/models/command_model.dart';

void main() {
  group('Command Validation Tests', () {
    test('Allows only valid defined commands in allowlist', () {
      const validActions = [
        'GET_STATUS',
        'GET_MOISTURE',
        'START_WATER',
        'STOP_WATER',
        'SET_AUTO_MODE',
        'SET_MANUAL_MODE',
        'MOVE_FORWARD',
        'MOVE_REVERSE',
        'TURN_LEFT',
        'TURN_RIGHT',
        'STOP_MOVEMENT',
        'STOP_ALL',
      ];

      for (final action in validActions) {
        expect(AppConstants.allowlistedActions.contains(action), isTrue);
      }

      // Dangerous or malicious commands must NOT be in allowlist
      const maliciousActions = [
        'EXEC_CODE',
        'GPIO_OVERRIDE',
        'FORMAT_FLASH',
        'RAW_WRITE',
        'BYPASS_SAFETY',
      ];

      for (final action in maliciousActions) {
        expect(AppConstants.allowlistedActions.contains(action), isFalse);
      }
    });

    test('Serializes CommandModel correctly to JSON', () {
      final cmd = CommandModel(
        commandId: "CMD_101",
        action: "START_WATER",
        params: {"duration_sec": 20},
        timestamp: DateTime(2026, 10, 28, 12, 0, 0),
      );

      final json = cmd.toJson();

      expect(json['command_id'], equals("CMD_101"));
      expect(json['action'], equals("START_WATER"));
      expect(json['params']['duration_sec'], equals(20));
      expect(json['timestamp'], equals("2026-10-28T12:00:00.000"));
    });
  });
}
