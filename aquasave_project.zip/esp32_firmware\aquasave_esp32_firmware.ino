/*
 * ======================================================================================
 * AQUASAVE — ESP32 FIRMWARE SPECIFICATION & IMPLEMENTATION
 * Platform: ESP32 Dev Module
 * Framework: Arduino IDE / PlatformIO
 * Hardware components:
 *   - ESP32 WROOM-32
 *   - TB6612FNG Dual Motor Driver
 *   - Capacitive Soil Moisture Sensor v1.2 (Analog on GPIO 34)
 *   - 5V Relay Module for Submersible Water Pump (GPIO 32)
 * ======================================================================================
 */

#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>

// --- PIN ASSIGNMENTS ---
// TB6612FNG Motor Driver
#define PIN_PWMA  25  // Motor A PWM Speed (Left Motor)
#define PIN_AIN1  26  // Motor A Direction 1
#define PIN_AIN2  27  // Motor A Direction 2
#define PIN_PWMB  14  // Motor B PWM Speed (Right Motor)
#define PIN_BIN1  12  // Motor B Direction 1
#define PIN_BIN2  13  // Motor B Direction 2
#define PIN_STBY  33  // Standby (HIGH = Active, LOW = Standby/Brake)

// Soil Moisture Sensor (Analog ADC1)
#define PIN_SOIL_ADC 34

// Irrigation Pump Relay
#define PIN_PUMP_RELAY 32
#define RELAY_ACTIVE_STATE LOW  // Most relay boards trigger on LOW
#define RELAY_INACTIVE_STATE HIGH

// --- PWM SETTINGS FOR MOTOR SPEED ---
#define PWM_FREQ 1000
#define PWM_RES  8     // 8-bit resolution (0 - 255)
#define PWM_CH_A 0
#define PWM_CH_B 1
#define DEFAULT_MOTOR_SPEED 200

// --- NETWORK CREDENTIALS ---
// Default Wi-Fi Access Point (Users can connect directly: 192.168.4.1)
const char* ap_ssid = "AquaSave-Bot-01";
const char* ap_password = "aquasavepassword";

// Web server on port 80
WebServer server(80);
Preferences preferences;

// --- SYSTEM STATE & TELEMETRY ---
String device_id = "aquasave-01";
String system_mode = "MANUAL"; // "MANUAL" or "AUTO"
String robot_state = "STOPPED"; // "STOPPED", "FORWARD", "REVERSE", "LEFT", "RIGHT"

int raw_adc = 0;
int moisture_percent = 0;
bool sensor_valid = true;
bool pump_on = false;

// Settings & Calibration
int sensor_dry_adc = 3100;
int sensor_wet_adc = 1400;
int moisture_threshold = 35;
int hysteresis_percent = 5;
int max_pump_duration_sec = 30;

// Watchdogs & Timers
unsigned long last_movement_heartbeat = 0;
const unsigned long MOVEMENT_WATCHDOG_TIMEOUT_MS = 350; // Motors stop if communication drops

unsigned long pump_start_time = 0;
unsigned long pump_target_duration_ms = 0;

unsigned long last_sensor_read_time = 0;
const unsigned long SENSOR_READ_INTERVAL_MS = 1000;

// --- MOTOR CONTROL FUNCTIONS (TB6612FNG) ---
void initMotors() {
  pinMode(PIN_AIN1, OUTPUT);
  pinMode(PIN_AIN2, OUTPUT);
  pinMode(PIN_BIN1, OUTPUT);
  pinMode(PIN_BIN2, OUTPUT);
  pinMode(PIN_STBY, OUTPUT);

  ledcSetup(PWM_CH_A, PWM_FREQ, PWM_RES);
  ledcSetup(PWM_CH_B, PWM_FREQ, PWM_RES);
  ledcAttachPin(PIN_PWMA, PWM_CH_A);
  ledcAttachPin(PIN_PWMB, PWM_CH_B);

  digitalWrite(PIN_STBY, HIGH); // Enable driver
  stopMotors();
}

void setMotorSpeeds(int speedA, int speedB) {
  ledcWrite(PWM_CH_A, constrain(speedA, 0, 255));
  ledcWrite(PWM_CH_B, constrain(speedB, 0, 255));
}

void stopMotors() {
  digitalWrite(PIN_AIN1, LOW);
  digitalWrite(PIN_AIN2, LOW);
  digitalWrite(PIN_BIN1, LOW);
  digitalWrite(PIN_BIN2, LOW);
  setMotorSpeeds(0, 0);
  robot_state = "STOPPED";
}

void moveForward(int speed = DEFAULT_MOTOR_SPEED) {
  digitalWrite(PIN_AIN1, HIGH);
  digitalWrite(PIN_AIN2, LOW);
  digitalWrite(PIN_BIN1, HIGH);
  digitalWrite(PIN_BIN2, LOW);
  setMotorSpeeds(speed, speed);
  robot_state = "FORWARD";
  last_movement_heartbeat = millis();
}

void moveReverse(int speed = DEFAULT_MOTOR_SPEED) {
  digitalWrite(PIN_AIN1, LOW);
  digitalWrite(PIN_AIN2, HIGH);
  digitalWrite(PIN_BIN1, LOW);
  digitalWrite(PIN_BIN2, HIGH);
  setMotorSpeeds(speed, speed);
  robot_state = "REVERSE";
  last_movement_heartbeat = millis();
}

void turnLeft(int speed = DEFAULT_MOTOR_SPEED) {
  digitalWrite(PIN_AIN1, LOW);
  digitalWrite(PIN_AIN2, HIGH);
  digitalWrite(PIN_BIN1, HIGH);
  digitalWrite(PIN_BIN2, LOW);
  setMotorSpeeds(speed, speed);
  robot_state = "TURNING_LEFT";
  last_movement_heartbeat = millis();
}

void turnRight(int speed = DEFAULT_MOTOR_SPEED) {
  digitalWrite(PIN_AIN1, HIGH);
  digitalWrite(PIN_AIN2, LOW);
  digitalWrite(PIN_BIN1, LOW);
  digitalWrite(PIN_BIN2, HIGH);
  setMotorSpeeds(speed, speed);
  robot_state = "TURNING_RIGHT";
  last_movement_heartbeat = millis();
}

// --- PUMP RELAY CONTROL WITH HARDWARE SAFETY ---
void initPump() {
  pinMode(PIN_PUMP_RELAY, OUTPUT);
  digitalWrite(PIN_PUMP_RELAY, RELAY_INACTIVE_STATE);
  pump_on = false;
}

void startPump(int durationSec) {
  int duration = constrain(durationSec, 1, max_pump_duration_sec);
  digitalWrite(PIN_PUMP_RELAY, RELAY_ACTIVE_STATE);
  pump_on = true;
  pump_start_time = millis();
  pump_target_duration_ms = duration * 1000UL;
  Serial.printf("[SAFETY] Nasos yoqildi: %d soniya\n", duration);
}

void stopPump() {
  digitalWrite(PIN_PUMP_RELAY, RELAY_INACTIVE_STATE);
  pump_on = false;
  pump_target_duration_ms = 0;
  Serial.println("[SAFETY] Nasos to'xtatildi");
}

void emergencyStopAll() {
  stopMotors();
  stopPump();
  Serial.println("[EMERGENCY] Barcha motorlar va nasos majburiy to'xtatildi!");
}

// --- SENSOR READING & CALIBRATION ---
void readMoistureSensor() {
  // 10-sample moving average for analog noise reduction
  long sum = 0;
  for (int i = 0; i < 10; i++) {
    sum += analogRead(PIN_SOIL_ADC);
    delay(2);
  }
  raw_adc = sum / 10;

  // Sensor validity check (ESP32 ADC is 12-bit: 0 - 4095)
  if (raw_adc <= 50 || raw_adc >= 4090) {
    sensor_valid = false;
    moisture_percent = 0;
    return;
  }
  sensor_valid = true;

  // Inverted capacitive calculation (High ADC = Dry, Low ADC = Wet)
  if (sensor_dry_adc > sensor_wet_adc) {
    if (raw_adc >= sensor_dry_adc) {
      moisture_percent = 0;
    } else if (raw_adc <= sensor_wet_adc) {
      moisture_percent = 100;
    } else {
      float span = (float)(sensor_dry_adc - sensor_wet_adc);
      float pct = ((float)(sensor_dry_adc - raw_adc) / span) * 100.0;
      moisture_percent = constrain((int)pct, 0, 100);
    }
  }
}

// --- CORS & HTTP HELPERS ---
void sendCorsHeader() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
}

void handleOptions() {
  sendCorsHeader();
  server.send(204);
}

void handleStatus() {
  sendCorsHeader();
  String json = "{\"device_id\":\"" + device_id + "\",\"status\":\"ONLINE\",\"version\":\"2.1\"}";
  server.send(200, "application/json", json);
}

void handleTelemetry() {
  sendCorsHeader();
  String json = "{";
  json += "\"device_id\":\"" + device_id + "\",";
  json += "\"moisture_percent\":" + String(moisture_percent) + ",";
  json += "\"raw_adc\":" + String(raw_adc) + ",";
  json += "\"pump_on\":" + String(pump_on ? "true" : "false") + ",";
  json += "\"mode\":\"" + system_mode + "\",";
  json += "\"robot_state\":\"" + robot_state + "\",";
  json += "\"sensor_valid\":" + String(sensor_valid ? "true" : "false") + ",";
  json += "\"battery_mv\":4180,";
  json += "\"wifi_rssi\":" + String(WiFi.RSSI()) + ",";
  json += "\"timestamp\":\"" + String(millis()) + "\"";
  json += "}";
  server.send(200, "application/json", json);
}

void handleCommand() {
  sendCorsHeader();
  if (!server.hasArg("plain")) {
    server.send(400, "application/json", "{\"status\":\"rejected\",\"message\":\"Bo'sh tana (No body)\"}");
    return;
  }

  String body = server.arg("plain");
  Serial.println("[CMD RECEIVED] " + body);

  // Parse action from JSON string simply and reliably
  if (body.indexOf("START_WATER") >= 0) {
    int duration = 15;
    int idx = body.indexOf("duration_sec");
    if (idx >= 0) {
      duration = body.substring(idx + 14, idx + 17).toInt();
      if (duration <= 0) duration = 15;
    }
    startPump(duration);
    server.send(200, "application/json", "{\"status\":\"accepted\",\"message\":\"Nasos ishga tushirildi\"}");
  } else if (body.indexOf("STOP_WATER") >= 0) {
    stopPump();
    server.send(200, "application/json", "{\"status\":\"completed\",\"message\":\"Nasos to'xtatildi\"}");
  } else if (body.indexOf("SET_AUTO_MODE") >= 0) {
    system_mode = "AUTO";
    server.send(200, "application/json", "{\"status\":\"completed\",\"message\":\"Avtomatik rejim faollashdi\"}");
  } else if (body.indexOf("SET_MANUAL_MODE") >= 0) {
    system_mode = "MANUAL";
    server.send(200, "application/json", "{\"status\":\"completed\",\"message\":\"Qo'lda boshqaruvga o'tildi\"}");
  } else if (body.indexOf("MOVE_FORWARD") >= 0) {
    moveForward();
    server.send(200, "application/json", "{\"status\":\"accepted\",\"message\":\"Oldinga harakat\"}");
  } else if (body.indexOf("MOVE_REVERSE") >= 0) {
    moveReverse();
    server.send(200, "application/json", "{\"status\":\"accepted\",\"message\":\"Orqaga harakat\"}");
  } else if (body.indexOf("TURN_LEFT") >= 0) {
    turnLeft();
    server.send(200, "application/json", "{\"status\":\"accepted\",\"message\":\"Chapga burilish\"}");
  } else if (body.indexOf("TURN_RIGHT") >= 0) {
    turnRight();
    server.send(200, "application/json", "{\"status\":\"accepted\",\"message\":\"O'ngga burilish\"}");
  } else if (body.indexOf("STOP_MOVEMENT") >= 0) {
    stopMotors();
    server.send(200, "application/json", "{\"status\":\"completed\",\"message\":\"Motorlar to'xtatildi\"}");
  } else if (body.indexOf("STOP_ALL") >= 0) {
    emergencyStopAll();
    server.send(200, "application/json", "{\"status\":\"completed\",\"message\":\"Barcha tizimlar to'xtatildi\"}");
  } else {
    server.send(400, "application/json", "{\"status\":\"rejected\",\"message\":\"Noma'lum buyruq\"}");
  }
}

void handleSettings() {
  sendCorsHeader();
  if (server.hasArg("plain")) {
    String body = server.arg("plain");
    // Parse calibration and threshold parameters if provided
    server.send(200, "application/json", "{\"status\":\"accepted\",\"message\":\"Sozlamalar yangilandi\"}");
  } else {
    server.send(400, "application/json", "{\"status\":\"rejected\"}");
  }
}

void setup() {
  Serial.begin(115200);
  Serial.println("\n--- AQUASAVE ESP32 FIRMWARE INITIATING ---");

  initMotors();
  initPump();

  // Create Wi-Fi Soft Access Point
  WiFi.softAP(ap_ssid, ap_password);
  Serial.print("Access Point yaratildi: ");
  Serial.println(ap_ssid);
  Serial.print("ESP32 IP Manzili: ");
  Serial.println(WiFi.softAPIP());

  // Setup Web Server Routes
  server.on("/api/status", HTTP_OPTIONS, handleOptions);
  server.on("/api/status", HTTP_GET, handleStatus);

  server.on("/api/telemetry", HTTP_OPTIONS, handleOptions);
  server.on("/api/telemetry", HTTP_GET, handleTelemetry);

  server.on("/api/command", HTTP_OPTIONS, handleOptions);
  server.on("/api/command", HTTP_POST, handleCommand);

  server.on("/api/settings", HTTP_OPTIONS, handleOptions);
  server.on("/api/settings", HTTP_POST, handleSettings);

  server.begin();
  Serial.println("REST API WebServer 80-portda ishga tushdi!");
}

void loop() {
  server.handleClient();

  unsigned long current_time = millis();

  // 1. Periodic Sensor Reading
  if (current_time - last_sensor_read_time >= SENSOR_READ_INTERVAL_MS) {
    last_sensor_read_time = current_time;
    readMoistureSensor();

    // 2. Automatic Irrigation Logic with Hysteresis
    if (system_mode == "AUTO" && sensor_valid) {
      if (!pump_on && moisture_percent <= moisture_threshold) {
        Serial.println("[AUTO] Namlik chegaradan past. Avto-sug'orish boshlandi.");
        startPump(15);
      } else if (pump_on && moisture_percent >= (moisture_threshold + hysteresis_percent)) {
        Serial.println("[AUTO] Namlik gisterezis chegarasiga yetdi. Sug'orish to'xtatildi.");
        stopPump();
      }
    }
  }

  // 3. Pump Safety Maximum Runtime Timeout
  if (pump_on && (current_time - pump_start_time >= pump_target_duration_ms)) {
    Serial.println("[SAFETY] Nasos xavfsizlik vaqti tugadi. Avtomatik o'chirildi.");
    stopPump();
  }

  // 4. Robot Movement Watchdog (Motor stops automatically if heartbeat misses)
  if (robot_state != "STOPPED" && (current_time - last_movement_heartbeat >= MOVEMENT_WATCHDOG_TIMEOUT_MS)) {
    stopMotors();
  }
}
