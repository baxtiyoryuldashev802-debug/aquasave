import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_theme.dart';
import '../controllers/aqua_ai_controller.dart';
import '../controllers/device_controller.dart';
import '../widgets/demo_banner.dart';

class AquaAiScreen extends StatefulWidget {
  const AquaAiScreen({super.key});

  @override
  State<AquaAiScreen> createState() => _AquaAiScreenState();
}

class _AquaAiScreenState extends State<AquaAiScreen> with SingleTickerProviderStateMixin {
  final TextEditingController _textController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  late AnimationController _pulseController;

  final List<String> _samplePrompts = [
    "AquaAI, tuproq namligi qancha?",
    "Sug'orishni boshlagin",
    "Nasosni to'xtat",
    "Avtomatik rejimni yoq",
    "Robotni oldinga yurgiz",
    "To'xta",
  ];

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _textController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final ai = context.watch<AquaAiController>();
    final dev = context.watch<DeviceController>();

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: AppColors.primaryGlow,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.auto_awesome_rounded, color: AppColors.primary, size: 20),
            ),
            const SizedBox(width: 10),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("AquaAI"),
                Text(
                  "Aqlli agronom va robot yordamchisi",
                  style: TextStyle(fontSize: 11, color: AppColors.textSecondary, fontWeight: FontWeight.w400),
                ),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: ai.speechFeedbackEnabled ? "Ovozli javob yoqilgan" : "Ovozli javob o'chiq",
            icon: Icon(
              ai.speechFeedbackEnabled ? Icons.volume_up_rounded : Icons.volume_off_rounded,
              color: ai.speechFeedbackEnabled ? AppColors.primary : AppColors.textMuted,
            ),
            onPressed: () => ai.toggleSpeechFeedback(),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            DemoBanner(
              isDemoMode: dev.isDemoMode,
              onToggle: () => dev.toggleDemoMode(!dev.isDemoMode),
            ),
            // Message List
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                itemCount: ai.messages.length,
                itemBuilder: (context, index) {
                  final msg = ai.messages[index];
                  return _buildMessageBubble(msg, ai);
                },
              ),
            ),

            // Sample Quick Questions Chips
            SizedBox(
              height: 40,
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                scrollDirection: Axis.horizontal,
                itemCount: _samplePrompts.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final p = _samplePrompts[index];
                  return ActionChip(
                    backgroundColor: AppColors.surfaceElevated,
                    side: const BorderSide(color: AppColors.surfaceBorder),
                    label: Text(
                      p,
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                    ),
                    onPressed: () {
                      ai.submitVoiceOrText(p);
                      _scrollToBottom();
                    },
                  );
                },
              ),
            ),
            const SizedBox(height: 12),

            // Voice & Text Input Bar
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: AppColors.surface,
                border: const Border(top: BorderSide(color: AppColors.surfaceBorder)),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Live transcription indicator
                  if (ai.state == AiState.listening) ...[
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: AppColors.primaryGlow,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppColors.primary.withOpacity(0.3)),
                      ),
                      child: Row(
                        children: [
                          AnimatedBuilder(
                            animation: _pulseController,
                            builder: (context, child) {
                              return Container(
                                width: 10,
                                height: 10,
                                decoration: BoxDecoration(
                                  color: AppColors.statusError,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: AppColors.statusError.withOpacity(_pulseController.value),
                                      blurRadius: 8,
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              ai.currentTranscription.isNotEmpty
                                  ? ai.currentTranscription
                                  : "Eshitmoqdaman... (O'zbek tilida gapiring)",
                              style: const TextStyle(
                                fontSize: 13,
                                color: AppColors.textPrimary,
                                fontStyle: FontStyle.italic,
                              ),
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close_rounded, size: 18),
                            onPressed: () => ai.cancelListening(),
                          ),
                        ],
                      ),
                    ),
                  ],

                  Row(
                    children: [
                      // Voice Listening Button
                      GestureDetector(
                        onTap: () {
                          if (ai.state == AiState.listening) {
                            ai.submitVoiceOrText();
                            _scrollToBottom();
                          } else {
                            ai.startListening();
                          }
                        },
                        child: AnimatedBuilder(
                          animation: _pulseController,
                          builder: (context, child) {
                            final isListening = ai.state == AiState.listening;
                            return Container(
                              width: 48,
                              height: 48,
                              decoration: BoxDecoration(
                                color: isListening ? AppColors.statusError : AppColors.primary,
                                shape: BoxShape.circle,
                                boxShadow: isListening
                                    ? [
                                        BoxShadow(
                                          color: AppColors.statusError.withOpacity(0.5),
                                          blurRadius: 12 * _pulseController.value,
                                        ),
                                      ]
                                    : [
                                        BoxShadow(
                                          color: AppColors.primaryGlow,
                                          blurRadius: 8,
                                        ),
                                      ],
                              ),
                              child: Icon(
                                isListening ? Icons.mic_rounded : Icons.mic_none_rounded,
                                color: Colors.black,
                                size: 24,
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 12),

                      // Text input field
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: AppColors.surfaceElevated,
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(color: AppColors.surfaceBorder),
                          ),
                          child: TextField(
                            controller: _textController,
                            style: const TextStyle(color: AppColors.textPrimary, fontSize: 14),
                            decoration: const InputDecoration(
                              hintText: "AquaAI ga yozing yoki ovoz bering...",
                              hintStyle: TextStyle(color: AppColors.textMuted, fontSize: 13),
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                            ),
                            onSubmitted: (val) {
                              if (val.trim().isNotEmpty) {
                                ai.submitVoiceOrText(val);
                                _textController.clear();
                                _scrollToBottom();
                              }
                            },
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),

                      // Send button
                      IconButton(
                        icon: const Icon(Icons.send_rounded, color: AppColors.primary),
                        onPressed: () {
                          if (_textController.text.trim().isNotEmpty) {
                            ai.submitVoiceOrText(_textController.text);
                            _textController.clear();
                            _scrollToBottom();
                          }
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage msg, AquaAiController ai) {
    return Align(
      alignment: msg.isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.all(14),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.82,
        ),
        decoration: BoxDecoration(
          color: msg.isUser ? const Color(0xFF065F46) : AppColors.surfaceElevated,
          borderRadius: BorderRadius.circular(18).copyWith(
            bottomRight: msg.isUser ? Radius.zero : const Radius.circular(18),
            bottomLeft: !msg.isUser ? Radius.zero : const Radius.circular(18),
          ),
          border: Border.all(
            color: msg.isUser ? AppColors.primary.withOpacity(0.3) : AppColors.surfaceBorder,
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              msg.text,
              style: TextStyle(
                color: msg.isUser ? Colors.white : AppColors.textPrimary,
                fontSize: 14,
                height: 1.4,
              ),
            ),
            if (msg.requiresConfirmation && msg.action != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.surfaceBorder.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      msg.confirmationPrompt ?? "Ushbu amalni bajarasizmi?",
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.secondary,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            foregroundColor: Colors.black,
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                            minimumSize: Size.zero,
                          ),
                          onPressed: () => ai.confirmAction(msg.action!),
                          child: const Text("Tasdiqlash", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                        ),
                        const SizedBox(width: 8),
                        TextButton(
                          onPressed: () {},
                          child: const Text("Bekor qilish", style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
