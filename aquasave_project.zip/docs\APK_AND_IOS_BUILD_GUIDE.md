# AQUASAVE — ANDROID APK VA IOS (IPHONE) DA O'RNATISH QO'LLANMASI

## 1. Muhim Texnik Tushuncha: APK va iOS

- **APK (`.apk`)** formati — Google Android operatsion tizimi (Samsung, Xiaomi, Redmi, Pixel, Honor va b.) uchun ishlab chiqilgan o'rnatish paketidir.
- **Apple iOS (iPhone va iPad)** operatsion tizimi xavfsizlik arxitekturasi tufayli `.apk` fayllarni to'g'ridan-to'g'ri o'qiy olmaydi. iOS ning o'ziga xos o'rnatish paketi **`.ipa`** (iOS App Store Package) deb ataladi.

**Ammo har ikkala platformada (Android ham, iOS ham) 100% birdek ishlaydigan 2 ta professional yechim mavjud:**
1. **Universal PWA (Progressive Web App):** 1 marta bosish orqali ham Android ga, ham iOS (iPhone) ga hech qanday do'konga kirmasdan to'liq avtonom ilova qilib o'rnatish.
2. **Flutter Native Build:** Android uchun toza `.apk`, iOS uchun esa `.ipa` yig'ish.

---

## 2. 1-Yechim: Universal PWA (Android va iOS uchun zudlik bilan o'rnatish)

AquaSave eng zamonaviy **PWA** standartlari bilan jihozlangan:
- `manifest.json` va `service-worker.js` sozlangan.
- Alohida ilova belgisi (Original AquaSave Botanical Icon), to'liq ekranli interfeys (brauzer ramkalarisiz).

### Android telefonda o'rnatish:
1. Kompyuteringizda simulyatorni ishga tushiring:
   ```cmd
   start_simulator.bat
   ```
2. Telefoningiz va kompyuteringiz bir xil Wi-Fi tarmog'ida bo'lsa, telefon brauzerida kompyuteringiz IP manzilini oching (masalan, `http://192.168.1.100:3000`).
3. Ekranning yuqorisidagi yashil **"O'rnatish"** tugmasini yoki brauzer menyusidan (3 nuqta) **"Ilovani o'rnatish" (Install App)** ni bosing.
4. Ilova telefoningiz bosh ekranida xuddi Play Marketdan o'rnatilgan APK kabi paydo bo'ladi.

### iOS (iPhone / iPad) da o'rnatish:
1. iPhone dagi **Safari** brauzerida AquaSave manzilini oching.
2. Safari pastki panelidagi **"Ulashish" (Share / kvadratdan chiquvchi strelka)** tugmasini bosing.
3. Menyu ro'yxatidan **"Bosh ekranga qo'shish" (Add to Home Screen / На экран «Домой»)** bandini tanlang.
4. **"Qo'shish" (Add)** tugmasini bosing.
5. iPhone bosh ekranida **AquaSave** belgisi paydo bo'ladi. Uni ochganingizda u hech qanday Safari panelsiz, to'liq ekranli haqiqiy iOS ilovasi sifatida ishlaydi!

---

## 3. 2-Yechim: Flutter orqali Android APK Yig'ish (Build APK)

Loyiha ichidagi `flutter_app/` papkasida Android uchun barcha ruxsatlar (`AndroidManifest.xml`) sozlangan:

### APK yaratish buyrug'i:
```bash
cd C:\Users\User\.gemini\antigravity\scratch\aquasave\flutter_app
flutter pub get
flutter build apk --release
```

**Natijaviy fayl joylashuvi:**
`flutter_app/build/app/outputs/flutter-apk/app-release.apk`

Ushbu `.apk` faylni istalgan Android telefoniga Telegram, USB kabel yoki Bluetooth orqali tashlab to'g'ridan-to'g'ri o'rnatishingiz mumkin.

---

## 4. Flutter orqali iOS (IPA) Yig'ish

Apple talablariga ko'ra, iOS ilovalari faqat macOS (MacBook / Mac mini) muhitida Xcode orqali yig'iladi:

```bash
cd flutter_app
flutter build ipa --no-codesign
```

Natija: `build/ios/archive/Runner.xcarchive` (yoki `.ipa`).
Keyin uni TestFlight yoki Apple Developer hisobi orqali iPhone ga o'rnatish mumkin.
