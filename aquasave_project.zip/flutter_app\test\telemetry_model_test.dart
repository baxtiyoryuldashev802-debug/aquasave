import 'package:flutter_test/flutter_test.dart';
import '../lib/models/telemetry_model.dart';

void main() {
  group('TelemetryModel Tests', () {
    test('Parses valid ESP32 telemetry JSON correctly', () {
      final json = {
        "device_id": "aquasave-01",
        "moisture_percent": 42,
        "raw_adc": 2150,
        "pump_on": false,
        "mode": "AUTO",
        "robot_state": "STOPPED",
        "sensor_valid": true,
        "timestamp": "2026-10-28T00:00:00Z",
        "battery_mv": 4120,
        "wifi_rssi": -62,
      };

      final telemetry = TelemetryModel.fromJson(json);

      expect(telemetry.deviceId, equals("aquasave-01"));
      expect(telemetry.moisturePercent, equals(42));
      expect(telemetry.rawAdc, equals(2150));
      expect(telemetry.pumpOn, isFalse);
      expect(telemetry.isAutoMode, isTrue);
      expect(telemetry.robotState, equals("STOPPED"));
      expect(telemetry.sensorValid, isTrue);
      expect(telemetry.batteryMv, equals(4120));
      expect(telemetry.wifiRssi, equals(-62));
    });

    test('Handles missing fields gracefully without crashing', () {
      final emptyJson = <String, dynamic>{};
      final telemetry = TelemetryModel.fromJson(emptyJson);

      expect(telemetry.moisturePercent, equals(0));
      expect(telemetry.pumpOn, isFalse);
      expect(telemetry.sensorValid, isFalse);
      expect(telemetry.mode, equals("MANUAL"));
      expect(telemetry.robotState, equals("STOPPED"));
    });

    test('Correctly identifies stale data', () {
      final oldTelemetry = TelemetryModel(
        deviceId: 'aquasave-01',
        moisturePercent: 30,
        rawAdc: 2400,
        pumpOn: false,
        mode: 'MANUAL',
        robotState: 'STOPPED',
        sensorValid: true,
        timestamp: DateTime.now().subtract(const Duration(seconds: 10)),
      );

      expect(oldTelemetry.isStale(const Duration(seconds: 5)), isTrue);

      final freshTelemetry = oldTelemetry.copyWith(timestamp: DateTime.now());
      expect(freshTelemetry.isStale(const Duration(seconds: 5)), isFalse);
    });
  });
}
