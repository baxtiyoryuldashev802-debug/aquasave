import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme.dart';
import 'controllers/history_controller.dart';
import 'controllers/device_controller.dart';
import 'controllers/aqua_ai_controller.dart';
import 'views/main_navigation_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AquaSaveApp());
}

class AquaSaveApp extends StatelessWidget {
  const AquaSaveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<HistoryController>(
          create: (_) => HistoryController(),
        ),
        ChangeNotifierProxyProvider<HistoryController, DeviceController>(
          create: (ctx) => DeviceController(
            historyController: ctx.read<HistoryController>(),
          ),
          update: (ctx, history, dev) =>
              dev ?? DeviceController(historyController: history),
        ),
        ChangeNotifierProxyProvider<DeviceController, AquaAiController>(
          create: (ctx) => AquaAiController(
            deviceController: ctx.read<DeviceController>(),
          ),
          update: (ctx, dev, ai) =>
              ai ?? AquaAiController(deviceController: dev),
        ),
      ],
      child: MaterialApp(
        title: 'AquaSave',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.darkTheme,
        home: const MainNavigationShell(),
      ),
    );
  }
}
