# AQUASAVE — SAFETY PROTOCOLS & ERROR HANDLING DOCUMENTATION

## 1. Safety Core Principles

AquaSave controls physical actuators (DC high-torque motors and water pump relays). As such, software safety is the top priority.

### 1.1. Dual-Watchdog Architecture
- **Firmware-side movement watchdog:** The ESP32 firmware monitors heartbeat packets. If no packet is received for **350 ms**, the TB6612FNG motor driver pins are immediately pulled `LOW` and `PWM` is set to `0`.
- **Relay maximum runtime watchdog:** The water pump relay has an un-bypassable hardware timer capping single activations to **30 seconds**. Even if the app crashes, the network disconnects, or the smartphone shuts down, the pump stops automatically.

### 1.2. Emergency Stop Interlock
- A high-visibility **FAVQULODDA TO'XTATISH** (Emergency Stop) button is present on all primary control screens.
- Tapping this button immediately broadcasts the `STOP_ALL` command, killing all motor PWM outputs, turning off the relay, and recording a high-priority safety alert in the system event history.

---

## 2. Sensor Fault Detection & Telemetry Verification

### 2.1. Soil Moisture ADC Sanity Checks
- ESP32 ADC range: `0` to `4095`.
- Readings $\le 50$ or $\ge 4090$ trigger an automatic **Sensor Fault** state (`sensor_valid = false`).
- When a sensor fault is detected:
  - Automatic irrigation is immediately suspended.
  - The UI displays an amber warning badge: **"Datchik xatosi"**.
  - The app never invents or guesses a moisture percentage.

### 2.2. Stale Data Handling
- Telemetry timestamps are compared against the local clock.
- If data is older than **5 seconds**, the connection indicator switches to **"Eski ma'lumot"** (Stale Data), and automatic command triggers are blocked until fresh readings arrive.

---

## 3. AquaAI Safety & Allowlisting

### 3.1. Strict Action Allowlist
The AI model cannot execute arbitrary code or toggle unmanaged GPIOs. Only the following actions are permitted:
- `GET_STATUS`
- `GET_MOISTURE`
- `START_WATER`
- `STOP_WATER`
- `SET_AUTO_MODE`
- `SET_MANUAL_MODE`
- `MOVE_FORWARD`
- `MOVE_REVERSE`
- `TURN_LEFT`
- `TURN_RIGHT`
- `STOP_MOVEMENT`
- `STOP_ALL`

### 3.2. Mandatory Confirmation for High-Risk Actions
Commands that actuate physical water (`START_WATER`) require explicit user confirmation via an interactive UI prompt before execution. Spurious voice commands in noisy environments will never trigger uncontrolled flooding.
