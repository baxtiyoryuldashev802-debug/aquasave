import 'package:flutter/foundation.dart';
import '../models/history_event_model.dart';

enum HistoryFilter { today, week, month }

class HistoryController extends ChangeNotifier {
  final List<HistoryEventModel> _events = [];
  HistoryFilter _selectedFilter = HistoryFilter.today;

  List<HistoryEventModel> get events => _filterEvents();
  HistoryFilter get selectedFilter => _selectedFilter;

  void setFilter(HistoryFilter filter) {
    _selectedFilter = filter;
    notifyListeners();
  }

  void addEvent({
    required HistoryEventType type,
    required String title,
    required String description,
    int? moistureValue,
    required bool isDemo,
  }) {
    final event = HistoryEventModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      timestamp: DateTime.now(),
      type: type,
      title: title,
      description: description,
      moistureValue: moistureValue,
      isDemo: isDemo,
    );
    _events.insert(0, event);
    if (_events.length > 200) {
      _events.removeLast();
    }
    notifyListeners();
  }

  List<HistoryEventModel> _filterEvents() {
    final now = DateTime.now();
    return _events.where((e) {
      if (_selectedFilter == HistoryFilter.today) {
        return e.timestamp.year == now.year &&
            e.timestamp.month == now.month &&
            e.timestamp.day == now.day;
      } else if (_selectedFilter == HistoryFilter.week) {
        return now.difference(e.timestamp).inDays <= 7;
      } else {
        return now.difference(e.timestamp).inDays <= 30;
      }
    }).toList();
  }

  void clearHistory() {
    _events.clear();
    notifyListeners();
  }
}
