enum CommandStatus {
  pending,
  accepted,
  rejected,
  completed,
  timeout,
  error
}

class CommandModel {
  final String commandId;
  final String action;
  final Map<String, dynamic> params;
  final DateTime timestamp;
  final CommandStatus status;
  final String? message;

  CommandModel({
    required this.commandId,
    required this.action,
    this.params = const {},
    required this.timestamp,
    this.status = CommandStatus.pending,
    this.message,
  });

  Map<String, dynamic> toJson() {
    return {
      'command_id': commandId,
      'action': action,
      'params': params,
      'timestamp': timestamp.toIso8601String(),
    };
  }

  CommandModel copyWith({
    String? commandId,
    String? action,
    Map<String, dynamic>? params,
    DateTime? timestamp,
    CommandStatus? status,
    String? message,
  }) {
    return CommandModel(
      commandId: commandId ?? this.commandId,
      action: action ?? this.action,
      params: params ?? this.params,
      timestamp: timestamp ?? this.timestamp,
      status: status ?? this.status,
      message: message ?? this.message,
    );
  }
}
