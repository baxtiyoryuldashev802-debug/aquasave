import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_theme.dart';
import '../controllers/device_controller.dart';
import '../core/constants/app_constants.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _nameController;
  late TextEditingController _ipController;
  late TextEditingController _proxyUrlController;
  int? _pingResultMs;
  bool _isTestingPing = false;

  @override
  void initState() {
    super.initState();
    final dev = context.read<DeviceController>();
    _nameController = TextEditingController(text: dev.settings.deviceName);
    _ipController = TextEditingController(text: dev.settings.esp32Host);
    _proxyUrlController = TextEditingController(text: dev.settings.openAiProxyUrl);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _ipController.dispose();
    _proxyUrlController.dispose();
    super.dispose();
  }

  Future<void> _testConnection(DeviceController dev) async {
    setState(() {
      _isTestingPing = true;
      _pingResultMs = null;
    });

    if (dev.isDemoMode) {
      await Future.delayed(const Duration(milliseconds: 600));
      setState(() {
        _isTestingPing = false;
        _pingResultMs = 12; // Simulated demo latency
      });
      return;
    }

    // Ping real ESP32
    final latency = await dev.pingEsp32();
    setState(() {
      _isTestingPing = false;
      _pingResultMs = latency;
    });
  }

  @override
  Widget build(BuildContext context) {
    final dev = context.watch<DeviceController>();
    final settings = dev.settings;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Sozlamalar va Qurilma"),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          children: [
            // Mode Selector: Demo vs Real
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.surfaceBorder),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Demo rejimi",
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        dev.isDemoMode
                            ? "Simulyatsiya faol (haqiqiy qurilma yo'q)"
                            : "ESP32 qurilmasi bilan jonli aloqa",
                        style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                      ),
                    ],
                  ),
                  Switch(
                    value: dev.isDemoMode,
                    onChanged: (val) {
                      dev.toggleDemoMode(val);
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Device details & ESP32 connection
            _buildSectionHeader("ESP32 Qurilma ulanishi"),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.surfaceBorder),
              ),
              child: Column(
                children: [
                  TextField(
                    controller: _nameController,
                    style: const TextStyle(color: AppColors.textPrimary),
                    decoration: const InputDecoration(
                      labelText: "Qurilma nomi",
                      labelStyle: TextStyle(color: AppColors.textMuted),
                    ),
                    onChanged: (val) {
                      dev.updateSettings(settings.copyWith(deviceName: val));
                    },
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _ipController,
                    style: const TextStyle(color: AppColors.textPrimary),
                    decoration: const InputDecoration(
                      labelText: "ESP32 IP manzili (Wi-Fi yoki AP)",
                      hintText: "192.168.4.1",
                      labelStyle: TextStyle(color: AppColors.textMuted),
                    ),
                    onChanged: (val) {
                      dev.updateSettings(settings.copyWith(esp32Host: val));
                    },
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.surfaceElevated,
                          foregroundColor: AppColors.primary,
                          side: const BorderSide(color: AppColors.surfaceBorder),
                        ),
                        onPressed: _isTestingPing ? null : () => _testConnection(dev),
                        icon: _isTestingPing
                            ? const SizedBox(
                                width: 14,
                                height: 14,
                                child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary),
                              )
                            : const Icon(Icons.network_check_rounded, size: 18),
                        label: const Text("Aloqani tekshirish (Ping)"),
                      ),
                      if (_pingResultMs != null)
                        Text(
                          "$_pingResultMs ms",
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            color: _pingResultMs! < 100 ? AppColors.connected : AppColors.statusDry,
                          ),
                        )
                      else if (_pingResultMs == null && !_isTestingPing)
                        const Text("--", style: TextStyle(color: AppColors.textMuted)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // SENSOR CALIBRATION WIZARD
            _buildSectionHeader("Namlik datchigini kalibrlash"),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.surfaceBorder),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        "Hozirgi ADC ko'rsatkichi:",
                        style: TextStyle(fontSize: 13, color: AppColors.textSecondary),
                      ),
                      Text(
                        dev.telemetry != null ? "${dev.telemetry!.rawAdc}" : "--",
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: AppColors.secondary,
                        ),
                      ),
                    ],
                  ),
                  const Divider(color: AppColors.surfaceBorder, height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Quruq havodagi ADC: ${settings.sensorDryAdc}",
                        style: const TextStyle(fontSize: 13, color: AppColors.textPrimary),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.surfaceElevated,
                          foregroundColor: AppColors.secondary,
                          minimumSize: Size.zero,
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        ),
                        onPressed: dev.telemetry != null
                            ? () {
                                dev.updateSettings(
                                  settings.copyWith(sensorDryAdc: dev.telemetry!.rawAdc),
                                );
                              }
                            : null,
                        child: const Text("Saqlash", style: TextStyle(fontSize: 11)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Suvdagi (Nam) ADC: ${settings.sensorWetAdc}",
                        style: const TextStyle(fontSize: 13, color: AppColors.textPrimary),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.surfaceElevated,
                          foregroundColor: AppColors.secondary,
                          minimumSize: Size.zero,
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        ),
                        onPressed: dev.telemetry != null
                            ? () {
                                dev.updateSettings(
                                  settings.copyWith(sensorWetAdc: dev.telemetry!.rawAdc),
                                );
                              }
                            : null,
                        child: const Text("Saqlash", style: TextStyle(fontSize: 11)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // AI & Security Settings
            _buildSectionHeader("AquaAI va Maxfiylik"),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.surfaceBorder),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: _proxyUrlController,
                    style: const TextStyle(color: AppColors.textPrimary, fontSize: 13),
                    decoration: const InputDecoration(
                      labelText: "AI Backend Proxy URL (OpenAI xavfsiz proksi)",
                      hintText: "http://localhost:3000/api/ai/chat",
                      labelStyle: TextStyle(color: AppColors.textMuted),
                    ),
                    onChanged: (val) {
                      dev.updateSettings(settings.copyWith(openAiProxyUrl: val));
                    },
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    "Xavfsizlik eslatmasi: OpenAI API kaliti ilovaning o'ziga joylashtirilmaydi. Barcha so'rovlar himoyalangan server orqali o'tadi.",
                    style: TextStyle(fontSize: 11, color: AppColors.textMuted, height: 1.4),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // App & Firmware Info
            _buildSectionHeader("Tizim ma'lumotlari"),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppColors.surfaceBorder),
              ),
              child: const Column(
                children: [
                  _InfoRow(label: "Ilova versiyasi", value: AppConstants.appVersion),
                  _InfoRow(label: "ESP32 Mikrodastur", value: "AquaSave-FW v2.1"),
                  _InfoRow(label: "Motor Drayveri", value: "TB6612FNG Dual H-Bridge"),
                  _InfoRow(label: "Asosiy til", value: "O'zbekcha (Lotin)"),
                ],
              ),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w700,
          color: AppColors.secondary,
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;

  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 13, color: AppColors.textMuted)),
          Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
        ],
      ),
    );
  }
}

extension DeviceControllerExt on DeviceController {
  Future<int?> pingEsp32() async {
    return await Esp32Client(host: settings.esp32Host, port: settings.esp32Port).ping();
  }
}
