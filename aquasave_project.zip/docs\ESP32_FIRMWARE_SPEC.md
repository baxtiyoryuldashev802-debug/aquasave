# AQUASAVE — ESP32 FIRMWARE & HARDWARE SPECIFICATION

## 1. Hardware Architecture Overview

AquaSave is built around the **ESP32 WROOM-32** dual-core microcontroller (240 MHz, 520 KB SRAM, 802.11 b/g/n Wi-Fi), designed to interface directly with:
1. **TB6612FNG Dual H-Bridge Motor Driver** — High-efficiency MOSFET-based motor driver for driving 2 DC gearmotors with hardware PWM speed control.
2. **Capacitive Soil Moisture Sensor v1.2** — Corrosion-resistant analog moisture sensor connected to ADC1.
3. **5V Optocoupler Relay Module** — Controls a 5V/12V DC submersible mini irrigation water pump.

---

## 2. Wiring & Pinout Table

| ESP32 Pin | Component Pin | Description | Voltage Level |
|---|---|---|---|
| **GPIO 25** | TB6612FNG `PWMA` | Left Motor PWM Speed | 3.3V Logic |
| **GPIO 26** | TB6612FNG `AIN1` | Left Motor Direction 1 | 3.3V Logic |
| **GPIO 27** | TB6612FNG `AIN2` | Left Motor Direction 2 | 3.3V Logic |
| **GPIO 14** | TB6612FNG `PWMB` | Right Motor PWM Speed | 3.3V Logic |
| **GPIO 12** | TB6612FNG `BIN1` | Right Motor Direction 1 | 3.3V Logic |
| **GPIO 13** | TB6612FNG `BIN2` | Right Motor Direction 2 | 3.3V Logic |
| **GPIO 33** | TB6612FNG `STBY` | Driver Standby Enable (HIGH = Run) | 3.3V Logic |
| **GPIO 34** | Capacitive Sensor `AOUT` | Analog Moisture Signal (ADC1_CH6) | 0 – 3.3V Analog |
| **GPIO 32** | 5V Relay `IN` | Pump Relay Control (Active LOW) | 3.3V/5V Logic |
| **3V3** | Sensor `VCC` | Analog Sensor Power Supply | 3.3V DC |
| **5V / VIN** | TB6612 `VCC`, Relay `VCC` | Logic / Relay Coil Power | 5.0V DC |
| **GND** | All Common GND | **Mandatory:** Connect all GNDs together! | 0V |
| **External Battery (6V-9V)** | TB6612 `VM` | Motor Power Supply | 6.0V – 9.0V DC |

> [!CAUTION]
> **Common Ground Rule:** The ESP32 GND and the external motor battery GND **MUST** be tied together. Never power DC motors directly from ESP32 GPIO pins or 3.3V regulator!

---

## 3. Motor Driver Specification (TB6612FNG)

- **PWM Frequency:** 1000 Hz, 8-bit resolution (0–255).
- **Default Speed:** 200 / 255 (~78% throttle) to ensure smooth torque on carpet and garden soil.
- **Direction Logic:**
  - **Forward:** `AIN1=HIGH, AIN2=LOW`, `BIN1=HIGH, BIN2=LOW`
  - **Reverse:** `AIN1=LOW, AIN2=HIGH`, `BIN1=LOW, BIN2=HIGH`
  - **Turn Left:** `AIN1=LOW, AIN2=HIGH`, `BIN1=HIGH, BIN2=LOW`
  - **Turn Right:** `AIN1=HIGH, AIN2=LOW`, `BIN1=LOW, BIN2=HIGH`
  - **Stop:** `AIN1=LOW, AIN2=LOW`, `BIN1=LOW, BIN2=LOW`, PWM = 0

---

## 4. Hardware Safety Watchdogs

### 4.1. Motor Heartbeat Timeout (350 ms)
To guarantee safety in case the Wi-Fi connection drops while the robot is moving:
- The mobile app sends directional movement commands continuously with a **200 ms interval**.
- The ESP32 checks `millis() - last_movement_heartbeat >= 350`.
- If no heartbeat is received within **350 ms**, the firmware **immediately stops all motors**.

### 4.2. Pump Maximum Runtime Timeout (Hard Limit)
- Even if a command specifies 60 seconds, the firmware enforces `max_pump_duration_sec = 30` (configurable up to a hard cap of 45s).
- An asynchronous timer in `loop()` turns off the relay immediately once time expires, preventing soil waterlogging or reservoir drainage.

---

## 5. Soil Moisture Sensor Calibration

The capacitive sensor outputs an inverted analog voltage:
- **Dry Air:** `~3100 ADC` (High voltage)
- **Submerged in Water:** `~1400 ADC` (Low voltage)

$$\text{Moisture \%} = \left(\frac{\text{Dry ADC} - \text{Current ADC}}{\text{Dry ADC} - \text{Wet ADC}}\right) \times 100$$

Clamped strictly between `0%` and `100%`.

---

## 6. REST API Endpoints

### `GET /api/status`
Returns basic online status:
```json
{
  "device_id": "aquasave-01",
  "status": "ONLINE",
  "version": "2.1"
}
```

### `GET /api/telemetry`
Returns complete hardware telemetry:
```json
{
  "device_id": "aquasave-01",
  "moisture_percent": 34,
  "raw_adc": 2320,
  "pump_on": false,
  "mode": "MANUAL",
  "robot_state": "STOPPED",
  "sensor_valid": true,
  "battery_mv": 4180,
  "wifi_rssi": -58,
  "timestamp": "1729892019"
}
```

### `POST /api/command`
Accepts structured commands:
```json
{
  "command_id": "CMD_1729892019",
  "action": "START_WATER",
  "params": { "duration_sec": 15 },
  "timestamp": "2026-10-28T00:00:00Z"
}
```
Response:
```json
{
  "status": "accepted",
  "message": "Nasos ishga tushirildi"
}
```
