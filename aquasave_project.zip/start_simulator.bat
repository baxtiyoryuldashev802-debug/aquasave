@echo off
title AquaSave Mobile Simulator & Backend Proxy
echo ========================================================
echo   AQUASAVE - SMART IRRIGATION ROBOT CONTROLLER
echo ========================================================
echo.
echo Starting Node.js backend proxy and mobile web simulator...
cd backend_proxy
call npm install
start "" http://localhost:3000
node server.js
pause
