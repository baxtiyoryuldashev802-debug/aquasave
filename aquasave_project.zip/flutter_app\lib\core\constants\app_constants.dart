class AppConstants {
  static const String appName = "AquaSave";
  static const String aiAssistantName = "AquaAI";
  static const String appVersion = "1.0.0-prod";

  // Default Network
  static const String defaultEsp32Ip = "192.168.4.1";
  static const int defaultEsp32Port = 80;
  static const Duration telemetryRefreshInterval = Duration(seconds: 1);
  static const Duration staleDataThreshold = Duration(seconds: 5);
  static const Duration commandTimeout = Duration(seconds: 3);

  // Safety Defaults
  static const int defaultMaxPumpRuntimeSec = 30;
  static const int defaultMoistureThresholdPercent = 35;
  static const int defaultHysteresisPercent = 5;
  static const int motorHeartbeatTimeoutMs = 350;

  // Calibration Defaults (12-bit ADC: 0 - 4095)
  // Capacitive soil moisture sensor: in air ~3100 (dry), in water ~1400 (wet)
  static const int defaultDryAdc = 3100;
  static const int defaultWetAdc = 1400;

  // Allowlisted Actions
  static const List<String> allowlistedActions = [
    'GET_STATUS',
    'GET_MOISTURE',
    'START_WATER',
    'STOP_WATER',
    'SET_AUTO_MODE',
    'SET_MANUAL_MODE',
    'MOVE_FORWARD',
    'MOVE_REVERSE',
    'TURN_LEFT',
    'TURN_RIGHT',
    'STOP_MOVEMENT',
    'STOP_ALL',
  ];
}
