import 'dart:math';
import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../core/utils/moisture_calculator.dart';

class MoistureGauge extends StatelessWidget {
  final int percentage;
  final MoistureState state;
  final bool isStale;
  final bool isValid;
  final double size;

  const MoistureGauge({
    super.key,
    required this.percentage,
    required this.state,
    required this.isStale,
    required this.isValid,
    this.size = 220,
  });

  Color _getStateColor() {
    if (!isValid) return AppColors.statusError;
    if (isStale) return AppColors.stale;
    switch (state) {
      case MoistureState.dry:
        return AppColors.statusDry;
      case MoistureState.normal:
        return AppColors.statusNormal;
      case MoistureState.wet:
        return AppColors.statusWet;
      case MoistureState.unknown:
        return AppColors.stale;
    }
  }

  @override
  Widget build(BuildContext context) {
    final stateColor = _getStateColor();
    final stateText = isValid
        ? (isStale ? "Eski ma'lumot" : MoistureCalculator.getStateTextUz(state))
        : "Datchik xatosi";

    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomPaint(
            size: Size(size, size),
            painter: _GaugePainter(
              percentage: isValid ? percentage.clamp(0, 100) : 0,
              accentColor: stateColor,
              backgroundColor: AppColors.surfaceBorder.withOpacity(0.4),
            ),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.water_drop_rounded,
                color: AppColors.secondary,
                size: 26,
              ),
              const SizedBox(height: 4),
              Text(
                isValid ? "$percentage%" : "--%",
                style: const TextStyle(
                  fontSize: 48,
                  fontWeight: FontWeight.w800,
                  color: AppColors.textPrimary,
                  letterSpacing: -2,
                ),
              ),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: stateColor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: stateColor.withOpacity(0.4), width: 1),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: stateColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      stateText,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: stateColor,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _GaugePainter extends CustomPainter {
  final int percentage;
  final Color accentColor;
  final Color backgroundColor;

  _GaugePainter({
    required this.percentage,
    required this.accentColor,
    required this.backgroundColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width / 2) - 14;
    const strokeWidth = 14.0;
    const startAngle = 135 * (pi / 180);
    const sweepTotalAngle = 270 * (pi / 180);

    // Background track
    final bgPaint = Paint()
      ..color = backgroundColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle,
      sweepTotalAngle,
      false,
      bgPaint,
    );

    // Active progress arc with glow
    final progressSweep = sweepTotalAngle * (percentage / 100);

    final glowPaint = Paint()
      ..color = accentColor.withOpacity(0.3)
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth + 6
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8)
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle,
      progressSweep,
      false,
      glowPaint,
    );

    final activePaint = Paint()
      ..shader = SweepGradient(
        startAngle: startAngle,
        endAngle: startAngle + sweepTotalAngle,
        colors: [
          accentColor.withOpacity(0.7),
          accentColor,
        ],
      ).createShader(Rect.fromCircle(center: center, radius: radius))
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle,
      progressSweep,
      false,
      activePaint,
    );
  }

  @override
  bool shouldRepaint(covariant _GaugePainter oldDelegate) {
    return oldDelegate.percentage != percentage || oldDelegate.accentColor != accentColor;
  }
}
